import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check } from "lucide-react";
import Backdrop from "./components/Backdrop";
import { MobileDock, Sidebar, TopBar, type PageId } from "./components/layout/Chrome";
import Dashboard from "./components/pages/Dashboard";
import Transactions from "./components/pages/Transactions";
import Splits from "./components/pages/Splits";
import Insights from "./components/pages/Insights";
import AddSheet from "./components/modals/AddSheet";
import ScannerModal from "./components/modals/ScannerModal";
import SplitSheet from "./components/modals/SplitSheet";
import { useLedger, type NewTx } from "./lib/useLedger";
import { generateAdvisory } from "./lib/insights";
import { formatINR } from "./lib/parser";
import { FRIENDS, type Tx } from "./lib/data";

export default function App() {
  const ledger = useLedger();
  const [page, setPage] = useState<PageId>("dashboard");
  const [addOpen, setAddOpen] = useState(false);
  const [scanOpen, setScanOpen] = useState(false);
  const [splitTx, setSplitTx] = useState<Tx | null>(null);

  /* the advisor reads the live ledger on every change */
  const advisory = useMemo(() => generateAdvisory(ledger.txs), [ledger.txs]);

  /* esc closes any open surface */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setAddOpen(false);
        setScanOpen(false);
        setSplitTx(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const handleAdd = (t: NewTx, via?: string) => {
    ledger.addTx(t);
    ledger.pushToast(
      `${t.type === "income" ? "Counted in" : "Logged"} · ${t.category} · ₹${formatINR(t.amount)}${via ? ` · ${via}` : ""}`,
      t.type
    );
  };

  return (
    <div className="min-h-screen bg-[#0d0c09] font-sans text-[#efe9db] antialiased selection:bg-[#ee4413] selection:text-[#f4f0e6]">
      <Backdrop />
      <div className="grain pointer-events-none fixed inset-0 z-[75] opacity-[0.05] mix-blend-soft-light" />

      <Sidebar page={page} onNav={setPage} />

      <div className="md:pl-60">
        <TopBar page={page} onAdd={() => setAddOpen(true)} onScan={() => setScanOpen(true)} />

        <main className="mx-auto max-w-[1200px] px-4 pb-32 pt-6 md:px-8 md:pb-16 md:pt-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 18, filter: "blur(5px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -12, filter: "blur(5px)" }}
              transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
            >
              {page === "dashboard" && (
                <Dashboard
                  txs={ledger.txs}
                  advisory={advisory}
                  onQuickAdd={(t) => handleAdd(t, "typed")}
                  onNav={setPage}
                />
              )}
              {page === "transactions" && (
                <Transactions
                  txs={ledger.txs}
                  onSplit={(tx) => setSplitTx(tx)}
                  onDelete={(id) => {
                    ledger.removeTx(id);
                    ledger.pushToast("Struck from the ledger", "info");
                  }}
                />
              )}
              {page === "splits" && (
                <Splits
                  splits={ledger.splits}
                  friends={FRIENDS}
                  onToggleSettled={(sid, fid) => {
                    ledger.toggleSettled(sid, fid);
                  }}
                  onNudge={(name) => ledger.pushToast(`Gentle nudge sent to ${name}`, "info")}
                  onRemove={(id) => {
                    ledger.removeSplit(id);
                    ledger.pushToast("Split archived — all square", "info");
                  }}
                />
              )}
              {page === "insights" && <Insights advisory={advisory} />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <MobileDock page={page} onNav={setPage} onAdd={() => setAddOpen(true)} />

      {/* ————— modals ————— */}
      <AddSheet open={addOpen} onClose={() => setAddOpen(false)} onAdd={(t) => handleAdd(t)} />
      <ScannerModal open={scanOpen} onClose={() => setScanOpen(false)} onAdd={(t) => handleAdd(t, "scanned")} />
      <SplitSheet
        open={!!splitTx}
        tx={splitTx}
        friends={FRIENDS}
        onClose={() => setSplitTx(null)}
        onCreate={(s) => {
          ledger.addSplit(s);
          ledger.pushToast(
            `Split recorded · ₹${formatINR(s.participants.reduce((a, c) => a + c.share, 0))} coming back`,
            "info"
          );
        }}
      />

      {/* ————— toasts ————— */}
      <div className="pointer-events-none fixed bottom-24 right-4 z-[80] flex flex-col items-end gap-2 md:bottom-8 md:right-8">
        <AnimatePresence>
          {ledger.toasts.map((t) => (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: 16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 480, damping: 32 }}
              className="flex items-center gap-2.5 rounded-full border border-white/10 bg-[#17140f]/95 px-4 py-2.5 shadow-[0_18px_44px_-12px_rgba(0,0,0,0.8)] backdrop-blur-xl"
            >
              <span
                className="grid h-4.5 w-4.5 place-items-center rounded-full"
                style={{
                  height: 18,
                  width: 18,
                  background:
                    t.kind === "income" ? "#1c9a67" : t.kind === "expense" ? "#ee4413" : "#3d382f",
                }}
              >
                <Check size={10} strokeWidth={3.5} color="#f4f0e6" />
              </span>
              <span className="whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.08em] text-[#efe9db]">
                {t.msg}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
