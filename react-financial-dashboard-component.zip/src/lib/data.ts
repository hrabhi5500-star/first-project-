/* ————————————————————————————————————————————————
   Folio data layer — mock ledger, budgets, friends
   All dates are generated relative to "today", so the
   dashboard always shows a living current month.
———————————————————————————————————————————————— */

export type TxType = "income" | "expense";

export interface Tx {
  id: number;
  type: TxType;
  amount: number;
  category: string;
  merchant: string;
  note?: string;
  date: string; // ISO YYYY-MM-DD
  source?: "note" | "manual" | "scan";
}

export interface Friend {
  id: string;
  name: string;
  color: string;
}

export interface SplitParticipant {
  friendId: string;
  share: number;
  settled: boolean;
}

export interface Split {
  id: number;
  title: string;
  category: string;
  total: number;
  date: string;
  participants: SplitParticipant[];
}

export interface Budget {
  category: string;
  limit: number;
}

/* ————— date helpers ————— */
const now = new Date();
const Y = now.getFullYear();
const M = now.getMonth(); // 0-indexed
const D = now.getDate();

const iso = (y: number, m: number, d: number) =>
  `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

const prevRef = new Date(Y, M - 1, 1);
const PY = prevRef.getFullYear();
const PM = prevRef.getMonth();

export const DAYS_IN_MONTH = new Date(Y, M + 1, 0).getDate();
export const DAYS_IN_PREV = new Date(PY, PM + 1, 0).getDate();
export const ELAPSED = D;
export const PACE = D / DAYS_IN_MONTH;

const cm = (day: number) => iso(Y, M, Math.min(day, D)); // current month, clamped to today
const pm = (day: number) => iso(PY, PM, Math.min(day, DAYS_IN_PREV));

export const CUR_KEY = iso(Y, M, 1).slice(0, 7);
export const PREV_KEY = iso(PY, PM, 1).slice(0, 7);
export const TODAY_ISO = iso(Y, M, D);

export const CUR_MONTH_NAME = now.toLocaleString("en-IN", { month: "long" });
export const PREV_MONTH_NAME = prevRef.toLocaleString("en-IN", { month: "long" });
export const CUR_YEAR = Y;

export const keyOf = (isoDate: string) => isoDate.slice(0, 7);

export function relLabel(isoDate: string): string {
  const d = new Date(isoDate + "T00:00:00");
  const t0 = new Date(Y, M, D);
  const diff = Math.round((t0.getTime() - d.getTime()) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
}

/* ————— seed ledger ————— */
let _id = 1;
const tx = (
  type: TxType,
  amount: number,
  category: string,
  merchant: string,
  date: string,
  note?: string
): Tx => ({ id: _id++, type, amount, category, merchant, date, note });

export const SEED_TXS: Tx[] = [
  /* current month — income */
  tx("income", 150000, "Salary", "Acme Studio", cm(1), `${CUR_MONTH_NAME} payroll`),
  tx("income", 12000, "Freelance", "Prae Design", cm(6), "Brand sprint invoice"),
  /* current month — expenses */
  tx("expense", 24000, "Utilities", "NestAway", cm(1), `${CUR_MONTH_NAME} rent`),
  tx("expense", 1180, "Groceries", "Blinkit", cm(2), "Weekly stock-up"),
  tx("expense", 420, "Coffee", "Third Wave", cm(3), "Pour over + croissant"),
  tx("expense", 800, "Transport", "Metro", cm(4), "Card top-up"),
  tx("expense", 640, "Food", "Swiggy", cm(4), "Late dinner"),
  tx("expense", 1299, "Fun", "PVR IMAX", cm(5), "Movie night"),
  tx("expense", 2899, "Shopping", "Myntra", cm(6), "Winter layer"),
  tx("expense", 240, "Coffee", "Blue Tokai", cm(7), "Flat white"),
  tx("expense", 2340, "Groceries", "Zepto", cm(8), "Pantry refill"),
  tx("expense", 1299, "Utilities", "Airtel", cm(9), "Wi-Fi recharge"),
  tx("expense", 940, "Food", "Sagar Ratna", cm(10), "Team lunch"),
  tx("expense", 900, "Transport", "Uber", cm(11), "Airport run"),
  tx("expense", 850, "Health", "Apollo Pharmacy", cm(12), "Vitamins"),
  tx("expense", 360, "Coffee", "Third Wave", cm(13), "Client meet"),
  tx("expense", 3200, "Food", "Toit", cm(13), "Team dinner"),
  tx("expense", 499, "Fun", "Spotify", cm(14), "Duo plan"),
  tx("expense", 1299, "Shopping", "Decathlon", cm(15), "Skipping rope + tee"),
  tx("expense", 980, "Groceries", "Blinkit", cm(15), "Snack run"),
  tx("expense", 260, "Transport", "Rapido", cm(16), "Home from metro"),
  tx("expense", 240, "Coffee", "Blue Tokai", cm(16), "Filter coffee"),
  /* previous month — income */
  tx("income", 150000, "Salary", "Acme Studio", pm(1), `${PREV_MONTH_NAME} payroll`),
  /* previous month — expenses */
  tx("expense", 24000, "Utilities", "NestAway", pm(1), `${PREV_MONTH_NAME} rent`),
  tx("expense", 1340, "Groceries", "BigBasket", pm(2)),
  tx("expense", 380, "Coffee", "Third Wave", pm(3)),
  tx("expense", 760, "Food", "Zomato", pm(5)),
  tx("expense", 1100, "Transport", "Uber", pm(6)),
  tx("expense", 1899, "Shopping", "Amazon", pm(7)),
  tx("expense", 240, "Coffee", "Blue Tokai", pm(8)),
  tx("expense", 1299, "Utilities", "Airtel", pm(9), "Wi-Fi recharge"),
  tx("expense", 1250, "Food", "Swiggy", pm(10)),
  tx("expense", 2100, "Groceries", "DMart", pm(11)),
  tx("expense", 499, "Fun", "Spotify", pm(12)),
  tx("expense", 450, "Coffee", "Third Wave", pm(13)),
  tx("expense", 3220, "Shopping", "Zara", pm(14)),
  tx("expense", 680, "Food", "Swiggy", pm(15)),
  tx("expense", 2200, "Transport", "Petrol", pm(16)),
  tx("expense", 799, "Health", "Apollo Pharmacy", pm(17)),
  tx("expense", 240, "Coffee", "Blue Tokai", pm(18)),
  tx("expense", 1850, "Groceries", "Zepto", pm(19)),
  tx("expense", 1499, "Fun", "BookMyShow", pm(20)),
  tx("expense", 890, "Food", "Udupi Café", pm(21)),
  tx("expense", 240, "Coffee", "Third Wave", pm(22)),
  tx("expense", 1420, "Groceries", "Blinkit", pm(23)),
  tx("expense", 949, "Utilities", "Vi Recharge", pm(24)),
].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);

export const FRIENDS: Friend[] = [
  { id: "f1", name: "Aarav", color: "#ee4413" },
  { id: "f2", name: "Meera", color: "#506ef5" },
  { id: "f3", name: "Zoya", color: "#1c9a67" },
  { id: "f4", name: "Kabir", color: "#b08a2e" },
];

export const SEED_SPLITS: Split[] = [
  {
    id: 101,
    title: "Toit — team dinner",
    category: "Food",
    total: 3200,
    date: cm(13),
    participants: [
      { friendId: "f1", share: 800, settled: false },
      { friendId: "f2", share: 800, settled: true },
      { friendId: "f3", share: 800, settled: false },
    ],
  },
  {
    id: 102,
    title: "Uber — airport run",
    category: "Transport",
    total: 900,
    date: cm(11),
    participants: [
      { friendId: "f4", share: 300, settled: false },
      { friendId: "f1", share: 300, settled: true },
    ],
  },
];

export const BUDGETS: Budget[] = [
  { category: "Utilities", limit: 27000 },
  { category: "Food", limit: 12000 },
  { category: "Groceries", limit: 9000 },
  { category: "Shopping", limit: 9000 },
  { category: "Transport", limit: 6000 },
  { category: "Fun", limit: 4000 },
  { category: "Health", limit: 3000 },
  { category: "Coffee", limit: 2500 },
];

/* ————— analytics helpers ————— */
export const inMonth = (t: Tx, key: string) => t.date.startsWith(key);
export const sum = (list: Tx[]) => list.reduce((a, c) => a + c.amount, 0);
export const monthExpense = (txs: Tx[], key: string) =>
  sum(txs.filter((t) => t.type === "expense" && inMonth(t, key)));
export const monthIncome = (txs: Tx[], key: string) =>
  sum(txs.filter((t) => t.type === "income" && inMonth(t, key)));

export function byCategory(txs: Tx[], key: string): { name: string; value: number }[] {
  const map: Record<string, number> = {};
  txs
    .filter((t) => t.type === "expense" && inMonth(t, key))
    .forEach((t) => (map[t.category] = (map[t.category] || 0) + t.amount));
  return Object.entries(map)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);
}

/* cumulative daily spend — current vs previous month, for the trend chart */
export function cumulativeSeries(txs: Tx[]) {
  const perDayCur: Record<number, number> = {};
  const perDayPrev: Record<number, number> = {};
  txs.forEach((t) => {
    if (t.type !== "expense") return;
    const day = parseInt(t.date.slice(8, 10), 10);
    if (t.date.startsWith(CUR_KEY)) perDayCur[day] = (perDayCur[day] || 0) + t.amount;
    if (t.date.startsWith(PREV_KEY)) perDayPrev[day] = (perDayPrev[day] || 0) + t.amount;
  });
  const out: { day: number; cur: number | null; prev: number }[] = [];
  let c = 0;
  let p = 0;
  for (let d = 1; d <= Math.max(DAYS_IN_MONTH, DAYS_IN_PREV); d++) {
    c += perDayCur[d] || 0;
    p += perDayPrev[d] || 0;
    out.push({ day: d, cur: d <= D ? c : null, prev: d <= DAYS_IN_PREV ? p : null as unknown as number });
  }
  return out;
}
