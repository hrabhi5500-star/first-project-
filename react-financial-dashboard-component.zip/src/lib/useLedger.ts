import { useCallback, useState } from "react";
import { SEED_SPLITS, SEED_TXS, type Split, type Tx } from "./data";

export interface ToastItem {
  id: number;
  msg: string;
  kind: "income" | "expense" | "info";
}

export type NewTx = Omit<Tx, "id">;

export function useLedger() {
  const [txs, setTxs] = useState<Tx[]>(SEED_TXS);
  const [splits, setSplits] = useState<Split[]>(SEED_SPLITS);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const pushToast = useCallback((msg: string, kind: ToastItem["kind"] = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  const addTx = useCallback((t: NewTx): Tx => {
    const tx: Tx = { ...t, id: Date.now() };
    setTxs((prev) =>
      [tx, ...prev].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id)
    );
    return tx;
  }, []);

  const removeTx = useCallback((id: number) => {
    setTxs((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const addSplit = useCallback((s: Omit<Split, "id">) => {
    setSplits((prev) => [{ ...s, id: Date.now() }, ...prev]);
  }, []);

  const toggleSettled = useCallback((splitId: number, friendId: string) => {
    setSplits((prev) =>
      prev.map((s) =>
        s.id === splitId
          ? {
              ...s,
              participants: s.participants.map((p) =>
                p.friendId === friendId ? { ...p, settled: !p.settled } : p
              ),
            }
          : s
      )
    );
  }, []);

  const removeSplit = useCallback((id: number) => {
    setSplits((prev) => prev.filter((s) => s.id !== id));
  }, []);

  return {
    txs,
    splits,
    toasts,
    pushToast,
    addTx,
    removeTx,
    addSplit,
    toggleSettled,
    removeSplit,
  };
}
