/* ————————————————————————————————————————————————
   Folio Advisor — rule-based insight engine.
   Reads the live ledger and writes notes like a
   very calm, slightly nerdy friend who loves money.
———————————————————————————————————————————————— */
import {
  PiggyBank,
  Coffee,
  TrendingUp,
  TrendingDown,
  PartyPopper,
  Repeat,
  Car,
  Target,
  type LucideIcon,
} from "lucide-react";
import {
  CUR_KEY,
  PREV_KEY,
  ELAPSED,
  CUR_MONTH_NAME,
  inMonth,
  monthExpense,
  monthIncome,
  type Tx,
} from "./data";
import { formatINR } from "./parser";

export type Impact = "high" | "medium" | "win";

export interface Tip {
  id: string;
  icon: LucideIcon;
  title: string;
  body: string;
  tag: string;
  impact: Impact;
}

export interface Fact {
  label: string;
  value: string;
}

export interface Advisory {
  score: number;
  grade: string;
  brief: string;
  tips: Tip[];
  facts: Fact[];
  savingsRate: number;
  paceRatio: number;
}

export function generateAdvisory(txs: Tx[]): Advisory {
  const cur = txs.filter((t) => inMonth(t, CUR_KEY));
  const expenses = cur.filter((t) => t.type === "expense");
  const curTotal = monthExpense(txs, CUR_KEY);
  const income = monthIncome(txs, CUR_KEY);
  const prevTotal = monthExpense(txs, PREV_KEY);

  /* previous month, sliced to the same day-of-month */
  const prevToDate = txs
    .filter((t) => t.type === "expense" && inMonth(t, PREV_KEY))
    .filter((t) => parseInt(t.date.slice(8, 10), 10) <= ELAPSED)
    .reduce((a, c) => a + c.amount, 0);

  const paceRatio = prevToDate > 0 ? curTotal / prevToDate : 1;
  void prevTotal;
  const savingsRate = income > 0 ? (income - curTotal) / income : 0;

  /* category aggregates (current month) */
  const cat: Record<string, number> = {};
  expenses.forEach((t) => (cat[t.category] = (cat[t.category] || 0) + t.amount));
  const sorted = Object.entries(cat).sort((a, b) => b[1] - a[1]);
  const discretionary = sorted.filter(([k]) => !["Utilities"].includes(k));
  const [topName] = sorted[0] ?? ["—"];
  const [funName, funAmt] = discretionary[0] ?? ["—", 0];

  /* coffee ritual */
  const coffeeTx = expenses.filter((t) => t.category === "Coffee");
  const coffeeTotal = coffeeTx.reduce((a, c) => a + c.amount, 0);
  const coffeeAvg = coffeeTx.length ? Math.round(coffeeTotal / coffeeTx.length) : 0;

  /* weekend share */
  const weekendTotal = expenses
    .filter((t) => {
      const dow = new Date(t.date + "T00:00:00").getDay();
      return dow === 0 || dow === 6;
    })
    .reduce((a, c) => a + c.amount, 0);
  const weekendShare = curTotal > 0 ? weekendTotal / curTotal : 0;

  /* weekday load */
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const perDow = [0, 0, 0, 0, 0, 0, 0];
  expenses.forEach((t) => {
    perDow[new Date(t.date + "T00:00:00").getDay()] += t.amount;
  });
  const biggestDow = dayNames[perDow.indexOf(Math.max(...perDow))];

  /* no-spend days */
  const daysWithSpend = new Set(expenses.map((t) => t.date)).size;
  const noSpendDays = Math.max(0, ELAPSED - daysWithSpend);

  const merchants = new Set(expenses.map((t) => t.merchant)).size;

  /* ————— the verdict ————— */
  const tips: Tip[] = [];

  tips.push(
    paceRatio > 1.02
      ? {
          id: "pace",
          icon: TrendingUp,
          impact: "high",
          tag: "Pace check",
          title: `${CUR_MONTH_NAME} is running ${Math.round((paceRatio - 1) * 100)}% hotter than last month`,
          body: `By day ${ELAPSED} you'd spent ₹${formatINR(prevToDate)} in ${"October"}; this month it's already ₹${formatINR(
            curTotal
          )}. A ₹${formatINR(Math.round(curTotal * 0.06))} discretionary freeze for 7 days pulls you back on the line.`,
        }
      : {
          id: "pace",
          icon: PartyPopper,
          impact: "win",
          tag: "Pace check",
          title: `Pacing ${Math.round((1 - paceRatio) * 100)}% under last month — genuinely`,
          body: `Same-day comparison: ₹${formatINR(curTotal)} vs ₹${formatINR(
            prevToDate
          )} this time last month. Move the surplus into savings tonight, before it evaporates into "just one treat".`,
        }
  );

  if (savingsRate >= 0.35) {
    tips.push({
      id: "sweep",
      icon: PiggyBank,
      impact: "win",
      tag: "Savings",
      title: `You're keeping ${Math.round(savingsRate * 100)} paise of every rupee`,
      body: `That's rare air. Automate a ₹${formatINR(
        Math.round(income * 0.3)
      )} sweep on the 2nd of every month so discipline never has to be a daily decision.`,
    });
  } else if (savingsRate < 0.2) {
    tips.push({
      id: "sweep",
      icon: PiggyBank,
      impact: "high",
      tag: "Savings",
      title: `Only ${Math.round(Math.max(savingsRate, 0) * 100)}% of income is surviving the month`,
      body: `Pay yourself first: a standing transfer of ₹${formatINR(
        Math.round(income * 0.2)
      )} on payday. What remains is what you may spend — not the other way around.`,
    });
  }

  if (coffeeTx.length >= 3) {
    tips.push({
      id: "coffee",
      icon: Coffee,
      impact: "medium",
      tag: "Rituals",
      title: `${coffeeTx.length} café runs · ₹${formatINR(coffeeTotal)} and counting`,
      body: `₹${formatINR(coffeeAvg)} a cup is a personality trait now — and that's fine. Brew at home twice a week and you quietly reclaim ~₹${formatINR(
        coffeeAvg * 8
      )} a month without losing the ritual.`,
    });
  }

  if (funName !== "—") {
    tips.push({
      id: "topcat",
      icon: Target,
      impact: topName === "Utilities" ? "medium" : "high",
      tag: "Concentration",
      title: `${funName} leads discretionary spend at ₹${formatINR(funAmt)}`,
      body: `${
        topName === "Utilities"
          ? "Rent and Wi-Fi are locked in — the lever lives elsewhere."
          : ""
      } Cap ${funName.toLowerCase()} at ₹${formatINR(
        Math.round(funAmt * 0.8)
      )} for the rest of ${CUR_MONTH_NAME}; one honest ceiling beats ten vague intentions.`,
    });
  }

  if (weekendShare > 0.42) {
    tips.push({
      id: "weekend",
      icon: TrendingDown,
      impact: "medium",
      tag: "Timing",
      title: `${Math.round(weekendShare * 100)}% of spending happens on weekends`,
      body: `A ₹2,000 weekend envelope — literally, in UPI terms — would cover the fun and stop the slow leaks. Weekdays are already behaving.`,
    });
  }

  const funTotal = cat["Fun"] || 0;
  if (funTotal > 1500 && tips.length < 6) {
    tips.push({
      id: "subs",
      icon: Repeat,
      impact: "medium",
      tag: "Subscriptions",
      title: `₹${formatINR(funTotal)} has gone to Fun this month`,
      body: `Streaming, tickets, plans. Rotate one streaming service per month instead of stacking three — the shows will wait, the auto-debits won't.`,
    });
  }

  const transportTotal = cat["Transport"] || 0;
  if (transportTotal > 1500 && tips.length < 6) {
    tips.push({
      id: "transport",
      icon: Car,
      impact: "medium",
      tag: "Getting around",
      title: `₹${formatINR(transportTotal)} on transport so far`,
      body: `Trading two cab rides a week for the metro saves roughly ₹${formatINR(
        Math.round(transportTotal * 0.35)
      )} a month — and it's usually faster past 6 PM anyway.`,
    });
  }

  const score = Math.max(
    6,
    Math.min(
      97,
      Math.round(
        44 +
          savingsRate * 58 +
          (paceRatio <= 1.02 ? 13 : -Math.min(14, (paceRatio - 1) * 90)) +
          Math.min(6, noSpendDays * 1.5)
      )
    )
  );

  const grade = score >= 85 ? "Excellent" : score >= 70 ? "Solid" : score >= 55 ? "Wobbly" : "Leaking";

  const brief =
    paceRatio > 1.02
      ? `${CUR_MONTH_NAME} is tracking ${Math.round((paceRatio - 1) * 100)}% ahead of where last month stood on day ${ELAPSED} — but your savings engine is still at ${Math.round(
          savingsRate * 100
        )}%. The story isn't danger; it's drift. Two small corrections below close the gap.`
      : `${CUR_MONTH_NAME} is behaving. You're ${Math.round(
          (1 - paceRatio) * 100
        )}% behind last month's pace with a ${Math.round(
          savingsRate * 100
        )}% savings rate. The only risk now is complacency — sweep the surplus before payday glow turns into impulse.`;

  const facts: Fact[] = [
    { label: "Avg coffee", value: coffeeAvg ? `₹${formatINR(coffeeAvg)}` : "—" },
    { label: "Heaviest day", value: biggestDow },
    { label: "No-spend days", value: `${noSpendDays}/${ELAPSED}` },
    { label: "Merchants", value: `${merchants}` },
  ];

  return {
    score,
    grade,
    brief,
    tips: tips.slice(0, 6),
    facts,
    savingsRate,
    paceRatio,
  };
}
