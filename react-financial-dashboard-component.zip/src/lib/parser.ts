import {
  Coffee,
  ShoppingBag,
  Utensils,
  Car,
  Zap,
  Wallet,
  Clapperboard,
  Store,
  HeartPulse,
  Briefcase,
  RotateCcw,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

export type TxType = "income" | "expense";

export interface Tx {
  id: number;
  type: TxType;
  amount: number;
  category: string;
  date: string;
  note: string;
}

export interface ParsedNote {
  amount: number;
  type: TxType;
  category: string;
  hasAmount: boolean;
}

/* ————————————————————————————————————————————————
   Category lookbook — ledger-toned ink + paper tints
———————————————————————————————————————————————— */
export const CATEGORY_META: Record<
  string,
  { icon: LucideIcon; color: string; bg: string }
> = {
  Coffee:    { icon: Coffee,      color: "#8F6200", bg: "#F1E5CB" },
  Groceries: { icon: ShoppingBag, color: "#1C7C4E", bg: "#DCECE2" },
  Food:      { icon: Utensils,    color: "#D93A0B", bg: "#F9E0D3" },
  Transport: { icon: Car,         color: "#2F6FED", bg: "#DEE8FB" },
  Utilities: { icon: Zap,         color: "#7C5CFC", bg: "#E9E4FD" },
  Salary:    { icon: Wallet,      color: "#0E7A5A", bg: "#DAEDE4" },
  Fun:       { icon: Clapperboard,color: "#CE3C5B", bg: "#F8DEE3" },
  Shopping:  { icon: Store,       color: "#0E8A8C", bg: "#DAECEE" },
  Health:    { icon: HeartPulse,  color: "#C2482F", bg: "#F4E0D8" },
  Freelance: { icon: Briefcase,   color: "#2F6FED", bg: "#DEE8FB" },
  Refund:    { icon: RotateCcw,   color: "#0E7A5A", bg: "#DAEDE4" },
  Misc:      { icon: Sparkles,    color: "#6B6457", bg: "#E7E2D4" },
};

export const EXPENSE_CATEGORIES = [
  "Food",
  "Coffee",
  "Groceries",
  "Transport",
  "Utilities",
  "Fun",
  "Shopping",
  "Misc",
];

export const INCOME_CATEGORIES = ["Salary", "Freelance", "Refund", "Misc"];

/* ————————————————————————————————————————————————
   Natural-language parser
   "chai ₹24 before standup"  → expense · Coffee · 24
   "received 2k freelance"    → income  · Freelance · 2000
———————————————————————————————————————————————— */
const INCOME_RE =
  /\b(received|recvd|got|credited|earned|salary|paycheck|stipend|refund|cashback|reimburs\w*|paid me|bonus|freelance|invoice|dividend|interest)\b/i;

const RULES: [RegExp, string][] = [
  [/\b(coffee|chai|cappuccino|latte|espresso|kaapi|starbucks|third wave|blue tokai)\b/i, "Coffee"],
  [/\b(grocer\w*|sabzi|vegetable|fruits?|blinkit|bigbasket|zepto|kirana|d-?mart|milk|eggs?|atta)\b/i, "Groceries"],
  [/\b(lunch|dinner|breakfast|food|meal|biryani|pizza|burger|swiggy|zomato|dhaba|snacks?|dosa|idli|thali|restaurant|brunch|dessert)\b/i, "Food"],
  [/\b(uber|ola|rapido|nami|cab|taxi|auto|metro|petrol|fuel|diesel|train|bus|flight|parking|toll|ride)\b/i, "Transport"],
  [/\b(bill|electricity|wi-?fi|broadband|recharge|rent|dth|gas|cylinder|water|maintenance|mobile plan)\b/i, "Utilities"],
  [/\b(movie|netflix|spotify|hotstar|prime|concert|games?|book|ipl|match|standup show|museum)\b/i, "Fun"],
  [/\b(shopping|clothes|shirt|kurti|shoes|sneakers|amazon|flipkart|myntra|mall|zara|uniqlo|watch)\b/i, "Shopping"],
  [/\b(gym|medicine|meds|tablet|doctor|pharmacy|apollo|health|yoga|protein|therapy|dentist)\b/i, "Health"],
  [/\b(salary|paycheck|stipend|payroll)\b/i, "Salary"],
  [/\b(freelance|client|invoice|gig|upwork)\b/i, "Freelance"],
  [/\b(refund|cashback|reimburs\w*|chargeback)\b/i, "Refund"],
];

export function parseNote(raw: string): ParsedNote {
  const lower = raw.trim().toLowerCase().replace(/,/g, "");

  /* amount — supports ₹500 · rs 500 · 1.5k · 2 thousand */
  let amount = 100;
  let hasAmount = false;
  const m = lower.match(/(?:rs\.?\s*|₹\s*)?(\d+(?:\.\d+)?)\s*(k|thousand)?\b/);
  if (m) {
    hasAmount = true;
    amount = Math.round(parseFloat(m[1]) * (m[2] ? 1000 : 1));
  }

  const type: TxType = INCOME_RE.test(lower) ? "income" : "expense";

  let category = type === "income" ? "Salary" : "Misc";
  for (const [re, cat] of RULES) {
    if (re.test(lower)) {
      category = cat;
      break;
    }
  }
  /* guard: expense-ish category matched on an income sentence */
  if (
    type === "income" &&
    ["Coffee", "Groceries", "Food", "Transport", "Utilities", "Fun", "Shopping", "Health"].includes(category)
  ) {
    category = "Salary";
  }

  return { amount, type, category, hasAmount };
}

/* ————————————————————————————————————————————————
   INR formatting — Indian digit grouping (1,50,000)
———————————————————————————————————————————————— */
export function formatINR(n: number): string {
  return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(n);
}

/* ————————————————————————————————————————————————
   Merchant guesses from natural language
———————————————————————————————————————————————— */
const MERCHANT_RULES: [RegExp, string][] = [
  [/\bswiggy\b/i, "Swiggy"],
  [/\bzomato\b/i, "Zomato"],
  [/\buber\b/i, "Uber"],
  [/\bola\b/i, "Ola"],
  [/\brapido\b/i, "Rapido"],
  [/\bmetro\b/i, "Metro"],
  [/\bblinkit\b/i, "Blinkit"],
  [/\bzepto\b/i, "Zepto"],
  [/\bbigbasket\b/i, "BigBasket"],
  [/\bamazon\b/i, "Amazon"],
  [/\bflipkart\b/i, "Flipkart"],
  [/\bmyntra\b/i, "Myntra"],
  [/\bzara\b/i, "Zara"],
  [/\bnetflix\b/i, "Netflix"],
  [/\bspotify\b/i, "Spotify"],
  [/\bairtel\b/i, "Airtel"],
  [/\b(chai|tea)\b/i, "Chai tapri"],
  [/\bcoffee\b/i, "Neighbourhood café"],
  [/\bsalary|paycheck|payroll\b/i, "Payroll"],
];

export function guessMerchant(note: string): string {
  for (const [re, name] of MERCHANT_RULES) {
    if (re.test(note)) return name;
  }
  return "Quick note";
}
