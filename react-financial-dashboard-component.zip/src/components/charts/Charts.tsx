import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";
import { CATEGORY_META, formatINR } from "../../lib/parser";
import AnimatedAmount from "../AnimatedAmount";

/* ————— shared tooltip skin ————— */
function tip(label: string, value: string, color?: string) {
  return (
    <div className="rounded-xl border border-white/10 bg-[#171410]/95 px-3 py-2 shadow-[0_16px_40px_-12px_rgba(0,0,0,0.8)] backdrop-blur-md">
      <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-[#7a7266]">{label}</p>
      <p className="mt-1 font-mono text-[13px] font-medium tabular-nums" style={{ color: color ?? "#efe9db" }}>
        {value}
      </p>
    </div>
  );
}

/* ————————————————————————————————————————————————
   Trend chart — this month vs last month, cumulative
———————————————————————————————————————————————— */
export function TrendChart({
  data,
  curName,
  prevName,
}: {
  data: { day: number; cur: number | null; prev: number }[];
  curName: string;
  prevName: string;
}) {
  return (
    <div className="h-[240px] w-full md:h-[280px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 6, left: 6, bottom: 0 }}>
          <defs>
            <linearGradient id="curFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ee4413" stopOpacity={0.32} />
              <stop offset="100%" stopColor="#ee4413" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} stroke="rgba(239,233,219,0.05)" />
          <XAxis
            dataKey="day"
            tick={{ fill: "#57503f", fontSize: 10, fontFamily: "IBM Plex Mono" }}
            axisLine={false}
            tickLine={false}
            tickMargin={10}
            interval={4}
          />
          <Tooltip
            cursor={{ stroke: "rgba(239,233,219,0.15)", strokeDasharray: "4 4" }}
            content={({ active, payload, label }) =>
              active && payload?.length
                ? tip(`Day ${label}`, `${curName}  ₹${formatINR(Number(payload.find((p) => p.dataKey === "cur")?.value ?? 0))}  ·  ${prevName}  ₹${formatINR(Number(payload.find((p) => p.dataKey === "prev")?.value ?? 0))}`)
                : null
            }
          />
          <Area
            type="monotone"
            dataKey="prev"
            stroke="#57503f"
            strokeWidth={1.6}
            strokeDasharray="5 5"
            fill="none"
            dot={false}
            connectNulls
          />
          <Area
            type="monotone"
            dataKey="cur"
            stroke="#ee4413"
            strokeWidth={2.4}
            fill="url(#curFill)"
            dot={false}
            connectNulls
            activeDot={{ r: 4, fill: "#ee4413", stroke: "#0d0c09", strokeWidth: 2 }}
            animationDuration={900}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ————————————————————————————————————————————————
   Category donut with centered total
———————————————————————————————————————————————— */
export function CategoryDonut({
  data,
  total,
}: {
  data: { name: string; value: number }[];
  total: number;
}) {
  return (
    <div className="relative h-[210px] w-full">
      {data.length > 0 ? (
        <>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius="68%"
                outerRadius="94%"
                paddingAngle={3}
                cornerRadius={6}
                dataKey="value"
                stroke="#0d0c09"
                strokeWidth={3}
                animationDuration={800}
              >
                {data.map((entry) => (
                  <Cell
                    key={entry.name}
                    fill={CATEGORY_META[entry.name]?.color ?? "#6b6457"}
                  />
                ))}
              </Pie>
              <Tooltip
                content={({ active, payload }) =>
                  active && payload?.length
                    ? tip(
                        String(payload[0].name),
                        `₹${formatINR(Number(payload[0].value))}`,
                        CATEGORY_META[String(payload[0].name)]?.color
                      )
                    : null
                }
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <div className="text-center">
              <p className="font-mono text-[8px] uppercase tracking-[0.28em] text-[#57503f]">Spent</p>
              <p className="mt-1 font-display text-[22px] font-semibold leading-none text-[#efe9db]">
                ₹<AnimatedAmount value={total} />
              </p>
            </div>
          </div>
        </>
      ) : (
        <div className="grid h-full place-items-center">
          <div className="grid h-36 w-36 place-items-center rounded-full border-2 border-dashed border-white/10">
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#57503f]">Nothing yet</span>
          </div>
        </div>
      )}
    </div>
  );
}
