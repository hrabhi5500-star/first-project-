import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Send } from "lucide-react";
import Sheet from "./Sheet";
import {
  CATEGORY_META,
  EXPENSE_CATEGORIES,
  INCOME_CATEGORIES,
  formatINR,
  guessMerchant,
  parseNote,
} from "../../lib/parser";
import { TODAY_ISO, type TxType } from "../../lib/data";
import type { NewTx } from "../../lib/useLedger";

interface Props {
  open: boolean;
  onClose: () => void;
  onAdd: (t: NewTx) => void;
}

const EXAMPLES = ["chai ₹24 before standup", "uber ₹380 to office", "Received 2k freelance", "₹1,299 wifi recharge"];

export default function AddSheet({ open, onClose, onAdd }: Props) {
  const [tab, setTab] = useState<"nl" | "manual">("nl");
  const [note, setNote] = useState("");

  /* manual */
  const [fType, setFType] = useState<TxType>("expense");
  const [fAmount, setFAmount] = useState("");
  const [fCat, setFCat] = useState("Food");
  const [fDate, setFDate] = useState(TODAY_ISO);
  const [fNote, setFNote] = useState("");

  useEffect(() => {
    if (open) {
      setNote("");
      setTab("nl");
      setFAmount("");
      setFNote("");
      setFDate(TODAY_ISO);
      setFType("expense");
      setFCat("Food");
    }
  }, [open]);

  const parsed = note.trim() ? parseNote(note) : null;

  const submitNL = (e: React.FormEvent) => {
    e.preventDefault();
    if (!note.trim() || !parsed) return;
    onAdd({
      type: parsed.type,
      amount: parsed.amount,
      category: parsed.category,
      merchant: guessMerchant(note),
      note: note.trim(),
      date: TODAY_ISO,
      source: "note",
    });
    onClose();
  };

  const submitManual = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Math.round(parseFloat(fAmount));
    if (!amount || amount <= 0) return;
    onAdd({
      type: fType,
      amount,
      category: fCat,
      merchant: fNote.trim() || "Manual entry",
      note: fNote.trim() || undefined,
      date: fDate || TODAY_ISO,
      source: "manual",
    });
    onClose();
  };

  return (
    <Sheet open={open} onClose={onClose} eyebrow="New entry" title="Ink it into the ledger">
      {/* tab seg */}
      <div className="relative grid grid-cols-2 rounded-full border border-white/10 bg-white/[0.03] p-1">
        {(["nl", "manual"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`relative z-10 py-2.5 text-[12px] font-semibold transition-colors ${
              tab === t ? "text-[#0d0c09]" : "text-[#7a7266]"
            }`}
          >
            {tab === t && (
              <motion.span
                layoutId="add-tab"
                transition={{ type: "spring", stiffness: 480, damping: 38 }}
                className="absolute inset-0 -z-10 rounded-full bg-[#efe9db]"
              />
            )}
            {t === "nl" ? "Say it" : "Fill it"}
          </button>
        ))}
      </div>

      {tab === "nl" ? (
        <form onSubmit={submitNL} className="mt-5">
          <div className="glass flex items-center gap-3 rounded-2xl px-4 py-1.5">
            <Sparkles size={15} className="shrink-0 text-[#ee4413]" />
            <input
              autoFocus
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Spent ₹500 on dinner…"
              className="min-w-0 flex-1 bg-transparent py-3.5 text-[14px] text-[#efe9db] outline-none placeholder:text-[#57503f]"
            />
            <motion.button
              whileTap={{ scale: 0.88 }}
              type="submit"
              disabled={!note.trim()}
              aria-label="Log it"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#ee4413] text-[#f4f0e6] transition-opacity disabled:opacity-30"
            >
              <Send size={14} className="ml-0.5" />
            </motion.button>
          </div>

          {/* live parse read-out */}
          <div className="mt-3 min-h-[34px]">
            {parsed && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex flex-wrap items-center gap-2"
              >
                <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 font-mono text-[9.5px] uppercase tracking-[0.14em] text-[#efe9db]">
                  {parsed.type === "income" ? "Income" : "Expense"}
                </span>
                <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 font-mono text-[9.5px] uppercase tracking-[0.14em] text-[#efe9db]">
                  {parsed.category}
                </span>
                <span
                  className="rounded-full border px-3 py-1.5 font-mono text-[9.5px] tabular-nums"
                  style={{
                    borderColor: parsed.type === "income" ? "rgba(80,200,140,0.3)" : "rgba(238,68,19,0.35)",
                    color: parsed.type === "income" ? "#58cf92" : "#ff7a4d",
                  }}
                >
                  {parsed.type === "income" ? "+" : "−"}₹{parsed.hasAmount ? formatINR(parsed.amount) : "···"}
                </span>
                <span className="rounded-full border border-white/10 px-3 py-1.5 font-mono text-[9.5px] text-[#7a7266]">
                  {guessMerchant(note)}
                </span>
              </motion.div>
            )}
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setNote(ex)}
                className="rounded-full border border-dashed border-white/15 px-3 py-1.5 font-mono text-[9.5px] text-[#7a7266] transition-colors hover:border-[#ee4413]/50 hover:text-[#efe9db]"
              >
                {ex}
              </button>
            ))}
          </div>
        </form>
      ) : (
        <form onSubmit={submitManual} className="mt-5 space-y-5">
          {/* type */}
          <div className="relative grid grid-cols-2 rounded-full border border-white/10 bg-white/[0.03] p-1">
            {(["expense", "income"] as TxType[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  setFType(t);
                  setFCat(t === "income" ? "Salary" : "Food");
                }}
                className={`relative z-10 py-2 text-[12px] font-semibold capitalize transition-colors ${
                  fType === t ? "text-[#0d0c09]" : "text-[#7a7266]"
                }`}
              >
                {fType === t && (
                  <motion.span
                    layoutId="manual-type"
                    transition={{ type: "spring", stiffness: 480, damping: 38 }}
                    className="absolute inset-0 -z-10 rounded-full bg-[#efe9db]"
                  />
                )}
                {t}
              </button>
            ))}
          </div>

          {/* amount + date */}
          <div className="grid grid-cols-[1fr_auto] gap-3">
            <div className="glass flex items-baseline gap-1 rounded-2xl px-4">
              <span className="font-display text-[20px] text-[#57503f]">₹</span>
              <input
                type="number"
                min="1"
                required
                value={fAmount}
                onChange={(e) => setFAmount(e.target.value)}
                placeholder="0"
                className="w-full min-w-0 bg-transparent py-3.5 font-display text-[24px] font-semibold text-[#efe9db] outline-none placeholder:text-[#3d382f]"
              />
            </div>
            <input
              type="date"
              value={fDate}
              max={TODAY_ISO}
              onChange={(e) => setFDate(e.target.value)}
              className="glass w-[150px] rounded-2xl px-3 py-3 font-mono text-[11px] text-[#efe9db] outline-none [color-scheme:dark]"
            />
          </div>

          {/* category */}
          <div>
            <p className="mb-2.5 font-mono text-[8.5px] uppercase tracking-[0.26em] text-[#57503f]">Category</p>
            <div className="grid grid-cols-4 gap-2">
              {(fType === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES).map((cat) => {
                const meta = CATEGORY_META[cat];
                const Icon = meta.icon;
                const active = fCat === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setFCat(cat)}
                    className={`flex flex-col items-center gap-1.5 rounded-xl border py-2.5 transition-colors ${
                      active ? "border-[#ee4413]/60 bg-[#ee4413]/[0.08]" : "border-white/[0.08] hover:border-white/20"
                    }`}
                  >
                    <Icon size={15} strokeWidth={2.1} style={{ color: meta.color }} />
                    <span className={`font-mono text-[8px] uppercase tracking-[0.06em] ${active ? "text-[#efe9db]" : "text-[#7a7266]"}`}>
                      {cat}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <input
            value={fNote}
            onChange={(e) => setFNote(e.target.value)}
            placeholder="Note / merchant (optional)"
            className="glass w-full rounded-2xl px-4 py-3.5 text-[13px] text-[#efe9db] outline-none placeholder:text-[#57503f]"
          />

          <motion.button
            whileTap={{ scale: 0.975 }}
            type="submit"
            className="w-full rounded-2xl bg-[#ee4413] py-4 text-[14px] font-semibold text-[#f4f0e6] shadow-[0_16px_40px_-12px_rgba(238,68,19,0.6)]"
          >
            Log transaction
          </motion.button>
        </form>
      )}
    </Sheet>
  );
}
