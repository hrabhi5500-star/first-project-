import type { ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  eyebrow?: string;
  title?: ReactNode;
  wide?: boolean;
  children: ReactNode;
}

/* Universal sheet: slides up as a bottom sheet on mobile,
   blooms as a centered glass modal on desktop. */
export default function Sheet({ open, onClose, eyebrow, title, wide, children }: Props) {
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center md:items-center md:p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-[6px]"
          />
          <motion.div
            initial={{ y: "104%", opacity: 0.4, scale: 0.99 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: "104%", opacity: 0 }}
            transition={{ type: "spring", stiffness: 360, damping: 38 }}
            className={`no-scrollbar relative z-10 max-h-[92svh] w-full overflow-y-auto rounded-t-[26px] border border-white/[0.09] bg-[#14120e]/97 shadow-[0_-20px_80px_rgba(0,0,0,0.6)] backdrop-blur-2xl md:rounded-[26px] md:shadow-[0_40px_120px_rgba(0,0,0,0.7)] ${
              wide ? "md:max-w-2xl" : "md:max-w-lg"
            }`}
          >
            <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-white/[0.06] bg-[#14120e]/97 px-5 pb-4 pt-4 backdrop-blur-2xl md:px-6">
              <div>
                {eyebrow && (
                  <p className="font-mono text-[8.5px] uppercase tracking-[0.28em] text-[#57503f]">{eyebrow}</p>
                )}
                {title && (
                  <h2 className="mt-1 font-display text-[22px] font-medium italic leading-none text-[#efe9db]">
                    {title}
                  </h2>
                )}
              </div>
              <button
                onClick={onClose}
                aria-label="Close"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-white/10 text-[#7a7266] transition-colors hover:border-white/25 hover:text-[#efe9db]"
              >
                <X size={14} />
              </button>
            </div>
            <div className="px-5 pb-8 pt-5 md:px-6">{children}</div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
