import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Users, BadgeCheck } from "lucide-react";
import Sheet from "./Sheet";
import { CATEGORY_META, formatINR } from "../../lib/parser";
import { TODAY_ISO, type Friend, type Split, type Tx } from "../../lib/data";

interface Props {
  open: boolean;
  tx: Tx | null;
  friends: Friend[];
  onClose: () => void;
  onCreate: (s: Omit<Split, "id">) => void;
}

export default function SplitSheet({ open, tx, friends, onClose, onCreate }: Props) {
  const [selected, setSelected] = useState<string[]>([]);
  const [mode, setMode] = useState<"even" | "custom">("even");
  const [custom, setCustom] = useState<Record<string, string>>({});

  const total = tx?.amount ?? 0;

  useEffect(() => {
    if (open) {
      setSelected(friends.map((f) => f.id));
      setMode("even");
      setCustom({});
    }
  }, [open, tx?.id, friends]);

  const evenShare = useMemo(
    () => (selected.length ? Math.round(total / (selected.length + 1)) : 0),
    [total, selected.length]
  );

  const shares: Record<string, number> = useMemo(() => {
    const out: Record<string, number> = {};
    selected.forEach((id) => {
      if (mode === "even") out[id] = evenShare;
      else {
        const raw = custom[id];
        out[id] = raw === undefined || raw === "" ? evenShare : Math.max(0, Math.round(Number(raw) || 0));
      }
    });
    return out;
  }, [selected, mode, evenShare, custom]);

  const friendsOwe = Object.values(shares).reduce((a, c) => a + c, 0);
  const youKeep = total - friendsOwe;
  const valid = selected.length > 0 && friendsOwe > 0 && youKeep >= 0;

  const toggle = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const create = () => {
    if (!tx || !valid) return;
    onCreate({
      title: tx.merchant,
      category: tx.category,
      total,
      date: tx.date || TODAY_ISO,
      participants: selected.map((fid) => ({ friendId: fid, share: shares[fid], settled: false })),
    });
    onClose();
  };

  const meta = tx ? CATEGORY_META[tx.category] ?? CATEGORY_META.Misc : CATEGORY_META.Misc;
  const TxIcon = meta.icon;

  return (
    <Sheet open={open} onClose={onClose} eyebrow="Bill splitting" title="Between friends">
      {tx && (
        <>
          {/* the bill */}
          <div className="glass flex items-center gap-3.5 rounded-2xl p-4">
            <span
              className="grid h-11 w-11 shrink-0 place-items-center rounded-xl"
              style={{ background: `${meta.color}1f`, color: meta.color }}
            >
              <TxIcon size={18} strokeWidth={2} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[14px] font-semibold text-[#efe9db]">{tx.merchant}</p>
              <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.18em] text-[#57503f]">
                {tx.category} · you fronted the whole thing
              </p>
            </div>
            <p className="font-display text-[22px] font-semibold tabular-nums text-[#efe9db]">
              ₹{formatINR(total)}
            </p>
          </div>

          {/* mode seg */}
          <div className="relative mt-5 grid grid-cols-2 rounded-full border border-white/10 bg-white/[0.03] p-1">
            {(["even", "custom"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`relative z-10 py-2 text-[12px] font-semibold capitalize transition-colors ${
                  mode === m ? "text-[#0d0c09]" : "text-[#7a7266]"
                }`}
              >
                {mode === m && (
                  <motion.span
                    layoutId="split-mode"
                    transition={{ type: "spring", stiffness: 480, damping: 38 }}
                    className="absolute inset-0 -z-10 rounded-full bg-[#efe9db]"
                  />
                )}
                {m === "even" ? "Split evenly" : "Custom shares"}
              </button>
            ))}
          </div>

          {/* friends */}
          <div className="mt-5 space-y-2">
            {friends.map((f) => {
              const on = selected.includes(f.id);
              return (
                <div
                  key={f.id}
                  className={`flex items-center gap-3 rounded-2xl border px-3.5 py-3 transition-colors ${
                    on ? "border-white/[0.14] bg-white/[0.035]" : "border-white/[0.06] opacity-50"
                  }`}
                >
                  <button
                    onClick={() => toggle(f.id)}
                    className="flex min-w-0 flex-1 items-center gap-3 text-left"
                  >
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-full font-display text-[14px] font-semibold"
                      style={{
                        background: on ? f.color : "rgba(255,255,255,0.07)",
                        color: on ? "#0d0c09" : "#7a7266",
                      }}
                    >
                      {f.name[0]}
                    </span>
                    <span className="truncate text-[13px] font-semibold text-[#efe9db]">{f.name}</span>
                  </button>
                  {on &&
                    (mode === "even" ? (
                      <span className="font-mono text-[12px] tabular-nums text-[#a39b8d]">
                        ₹{formatINR(shares[f.id] ?? 0)}
                      </span>
                    ) : (
                      <div className="flex items-center gap-1 rounded-lg border border-white/12 px-2.5 py-1.5">
                        <span className="font-mono text-[11px] text-[#57503f]">₹</span>
                        <input
                          type="number"
                          min="0"
                          value={custom[f.id] ?? evenShare}
                          onChange={(e) => setCustom({ ...custom, [f.id]: e.target.value })}
                          className="w-16 bg-transparent font-mono text-[12px] tabular-nums text-[#efe9db] outline-none"
                        />
                      </div>
                    ))}
                </div>
              );
            })}
          </div>

          {/* tally */}
          <div className="mt-5 flex items-center justify-between rounded-xl border border-dashed border-white/15 px-4 py-3">
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#7a7266]">
              You keep · <span className="text-[#efe9db]">₹{formatINR(Math.max(0, youKeep))}</span>
            </span>
            <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#7a7266]">
              Friends owe ·{" "}
              <span className={friendsOwe > total ? "text-[#ff7a4d]" : "text-[#58cf92]"}>
                ₹{formatINR(friendsOwe)}
              </span>
            </span>
          </div>
          {friendsOwe > total && (
            <p className="mt-2 text-right font-mono text-[9px] uppercase tracking-[0.14em] text-[#ff7a4d]">
              Shares exceed the bill — trim a little
            </p>
          )}

          <motion.button
            whileTap={{ scale: 0.975 }}
            onClick={create}
            disabled={!valid}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#ee4413] py-4 text-[14px] font-semibold text-[#f4f0e6] shadow-[0_16px_40px_-12px_rgba(238,68,19,0.6)] disabled:opacity-35"
          >
            <Users size={16} />
            Record split with {selected.length} {selected.length === 1 ? "friend" : "friends"}
          </motion.button>
          <p className="mt-3 flex items-center justify-center gap-1.5 text-center font-mono text-[8.5px] uppercase tracking-[0.2em] text-[#57503f]">
            <BadgeCheck size={11} /> They'll show up on the Splits page, gently pending
          </p>
        </>
      )}
    </Sheet>
  );
}
