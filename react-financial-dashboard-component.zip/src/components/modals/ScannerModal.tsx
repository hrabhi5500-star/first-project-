import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { UploadCloud, Check, ScanLine, RotateCcw, FileImage } from "lucide-react";
import Sheet from "./Sheet";
import { CATEGORY_META, EXPENSE_CATEGORIES, formatINR } from "../../lib/parser";
import { TODAY_ISO } from "../../lib/data";
import type { NewTx } from "../../lib/useLedger";

interface Props {
  open: boolean;
  onClose: () => void;
  onAdd: (t: NewTx) => void;
}

type Stage = "idle" | "reading" | "review" | "saved";

interface Extracted {
  merchant: string;
  amount: number;
  date: string;
  category: string;
}

const PRESETS: Extracted[] = [
  { merchant: "Third Wave Coffee Roasters", amount: 860, date: TODAY_ISO, category: "Coffee" },
  { merchant: "Swiggy Instamart", amount: 1240, date: TODAY_ISO, category: "Groceries" },
  { merchant: "PVR Cinemas", amount: 1498, date: TODAY_ISO, category: "Fun" },
  { merchant: "Uber India", amount: 649, date: TODAY_ISO, category: "Transport" },
  { merchant: "MTR 1924", amount: 1140, date: TODAY_ISO, category: "Food" },
];

const SAMPLE: Extracted = {
  merchant: "The Hole-in-the-Wall Café",
  amount: 912,
  date: TODAY_ISO,
  category: "Food",
};

const STEPS = ["Reading pixels…", "Isolating merchant…", "Parsing line items…", "Tallying the total…"];

export default function ScannerModal({ open, onClose, onAdd }: Props) {
  const [stage, setStage] = useState<Stage>("idle");
  const [stepIdx, setStepIdx] = useState(0);
  const [preview, setPreview] = useState<string | null>(null);
  const [data, setData] = useState<Extracted>(SAMPLE);
  const fileRef = useRef<HTMLInputElement>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    if (!open) {
      timers.current.forEach(clearTimeout);
      timers.current = [];
      setStage("idle");
      setStepIdx(0);
      setPreview(null);
    }
    return () => {
      timers.current.forEach(clearTimeout);
      timers.current = [];
    };
  }, [open]);

  const beginReading = (preset: Extracted, image: string | null) => {
    setData(preset);
    setPreview(image);
    setStage("reading");
    setStepIdx(0);
    STEPS.forEach((_, i) => {
      timers.current.push(setTimeout(() => setStepIdx(i + 1), 750 * (i + 1)));
    });
    timers.current.push(setTimeout(() => setStage("review"), 750 * STEPS.length + 400));
  };

  const onFile = (f: File | undefined) => {
    if (!f) return;
    /* deterministic pseudo-extraction from the file — the "AI" reads vibes */
    const idx = (f.name.length + f.size) % PRESETS.length;
    const reader = new FileReader();
    reader.onload = () => beginReading(PRESETS[idx], String(reader.result));
    reader.readAsDataURL(f);
  };

  const confirm = () => {
    onAdd({
      type: "expense",
      amount: Math.round(Number(data.amount)) || 0,
      category: data.category,
      merchant: data.merchant || "Scanned receipt",
      note: "Scanned receipt",
      date: data.date || TODAY_ISO,
      source: "scan",
    });
    setStage("saved");
    timers.current.push(setTimeout(onClose, 1100));
  };

  const Icon = CATEGORY_META[data.category]?.icon ?? ScanLine;

  return (
    <Sheet open={open} onClose={onClose} eyebrow="Smart scanner" title="Feed me a receipt" wide>
      <input
        ref={fileRef}
        type="file"
        accept="image/*,.pdf"
        className="hidden"
        onChange={(e) => onFile(e.target.files?.[0])}
      />

      <AnimatePresence mode="wait">
        {/* ————— idle: dropzone ————— */}
        {stage === "idle" && (
          <motion.div
            key="idle"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
          >
            <button
              onClick={() => fileRef.current?.click()}
              className="group flex w-full flex-col items-center gap-4 rounded-2xl border-2 border-dashed border-white/15 px-6 py-12 text-center transition-colors hover:border-[#ee4413]/50 hover:bg-[#ee4413]/[0.03]"
            >
              <span className="grid h-14 w-14 place-items-center rounded-full border border-white/10 bg-white/[0.04] transition-transform duration-300 group-hover:-translate-y-1">
                <UploadCloud size={22} className="text-[#ee4413]" strokeWidth={1.8} />
              </span>
              <span>
                <span className="block text-[14px] font-semibold text-[#efe9db]">
                  Drop a bill, screenshot or PDF
                </span>
                <span className="mt-1 block font-mono text-[9px] uppercase tracking-[0.22em] text-[#57503f]">
                  JPG · PNG · PDF — the AI reads them all
                </span>
              </span>
            </button>
            <div className="mt-4 flex items-center justify-center gap-3">
              <span className="h-px w-10 bg-white/10" />
              <button
                onClick={() => beginReading(SAMPLE, null)}
                className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-[#7a7266] underline decoration-dotted underline-offset-4 transition-colors hover:text-[#efe9db]"
              >
                or try a sample receipt
              </button>
              <span className="h-px w-10 bg-white/10" />
            </div>
          </motion.div>
        )}

        {/* ————— reading: scan simulation ————— */}
        {stage === "reading" && (
          <motion.div key="reading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black/40">
              <div className="relative mx-auto h-56 w-full max-w-sm">
                {preview ? (
                  <img src={preview} alt="Receipt" className="h-full w-full object-cover opacity-80" />
                ) : (
                  /* drawn sample receipt */
                  <div className="mx-auto mt-4 w-56 rounded-t-lg bg-[#f4f0e6] px-4 py-4 font-mono text-[8px] leading-[1.9] text-[#3d382f]">
                    <p className="text-center text-[9px] font-semibold tracking-[0.2em]">HOLE-IN-THE-WALL CAFÉ</p>
                    <p className="text-center tracking-[0.14em] text-[#8a8272]">Koramangala · Bengaluru</p>
                    <div className="my-2 border-t border-dashed border-[#b0a88f]" />
                    <p className="flex justify-between"><span>2× Masala dosa</span><span>420.00</span></p>
                    <p className="flex justify-between"><span>1× Filter coffee</span><span>140.00</span></p>
                    <p className="flex justify-between"><span>1× Benne dosa</span><span>210.00</span></p>
                    <p className="flex justify-between"><span>GST 5%</span><span>42.00</span></p>
                    <div className="my-2 border-t border-dashed border-[#b0a88f]" />
                    <p className="flex justify-between font-semibold"><span>TOTAL</span><span>₹912.00</span></p>
                  </div>
                )}
                {/* travelling scan beam */}
                <motion.div
                  initial={{ top: "-8%" }}
                  animate={{ top: ["-8%", "104%", "-8%"] }}
                  transition={{ duration: 3.1, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-x-0 h-10 bg-gradient-to-b from-transparent via-[#ee4413]/35 to-transparent"
                />
                <motion.div
                  initial={{ top: "-2%" }}
                  animate={{ top: ["-2%", "100%", "-2%"] }}
                  transition={{ duration: 3.1, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-x-0 h-[2px] bg-[#ee4413] shadow-[0_0_18px_rgba(238,68,19,0.9)]"
                />
              </div>
            </div>

            {/* progress */}
            <div className="mt-5">
              <div className="h-1 overflow-hidden rounded-full bg-white/[0.07]">
                <motion.div
                  initial={{ width: "4%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 3.3, ease: [0.3, 0.7, 0.4, 1] }}
                  className="h-full rounded-full bg-gradient-to-r from-[#ee4413] to-[#f5a524]"
                />
              </div>
              <ul className="mt-4 space-y-2.5">
                {STEPS.map((s, i) => {
                  const done = stepIdx > i;
                  const active = stepIdx === i;
                  return (
                    <li key={s} className="flex items-center gap-2.5">
                      <span
                        className={`grid h-4.5 w-4.5 place-items-center rounded-full border transition-colors ${
                          done ? "border-[#1c9a67] bg-[#1c9a67]/20" : active ? "border-[#ee4413]/60" : "border-white/15"
                        }`}
                        style={{ height: 18, width: 18 }}
                      >
                        {done ? (
                          <Check size={10} strokeWidth={3.2} className="text-[#58cf92]" />
                        ) : active ? (
                          <motion.span
                            animate={{ opacity: [1, 0.25, 1] }}
                            transition={{ duration: 0.9, repeat: Infinity }}
                            className="h-1.5 w-1.5 rounded-full bg-[#ee4413]"
                          />
                        ) : null}
                      </span>
                      <span className={`font-mono text-[10px] tracking-[0.06em] ${done ? "text-[#7a7266] line-through" : active ? "text-[#efe9db]" : "text-[#57503f]"}`}>
                        {s}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </div>
          </motion.div>
        )}

        {/* ————— review: extracted fields ————— */}
        {(stage === "review" || stage === "saved") && (
          <motion.div key="review" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            {/* summary strip */}
            <div className="glass flex items-center gap-4 rounded-2xl p-4">
              <span
                className="grid h-11 w-11 shrink-0 place-items-center rounded-xl"
                style={{ background: `${CATEGORY_META[data.category]?.color}1f`, color: CATEGORY_META[data.category]?.color }}
              >
                <Icon size={18} strokeWidth={2} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[14px] font-semibold text-[#efe9db]">{data.merchant}</p>
                <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.2em] text-[#57503f]">
                  extracted · confidence 98.2%
                </p>
              </div>
              <p className="font-display text-[22px] font-semibold tabular-nums text-[#efe9db]">
                ₹{formatINR(Number(data.amount) || 0)}
              </p>
            </div>

            {/* editable fields */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              <label className="col-span-2 block">
                <span className="mb-1.5 block font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">Merchant</span>
                <input
                  value={data.merchant}
                  onChange={(e) => setData({ ...data, merchant: e.target.value })}
                  className="glass w-full rounded-xl px-3.5 py-3 text-[13px] text-[#efe9db] outline-none"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">Amount (₹)</span>
                <input
                  type="number"
                  min="1"
                  value={data.amount}
                  onChange={(e) => setData({ ...data, amount: Number(e.target.value) })}
                  className="glass w-full rounded-xl px-3.5 py-3 font-mono text-[13px] tabular-nums text-[#efe9db] outline-none"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">Date</span>
                <input
                  type="date"
                  value={data.date}
                  max={TODAY_ISO}
                  onChange={(e) => setData({ ...data, date: e.target.value })}
                  className="glass w-full rounded-xl px-3.5 py-3 font-mono text-[12px] text-[#efe9db] outline-none [color-scheme:dark]"
                />
              </label>
              <div className="col-span-2">
                <span className="mb-1.5 block font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">Category</span>
                <div className="flex flex-wrap gap-1.5">
                  {EXPENSE_CATEGORIES.map((c) => (
                    <button
                      key={c}
                      onClick={() => setData({ ...data, category: c })}
                      className={`rounded-full border px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.1em] transition-colors ${
                        data.category === c
                          ? "border-[#ee4413]/60 bg-[#ee4413]/[0.1] text-[#efe9db]"
                          : "border-white/10 text-[#7a7266] hover:border-white/25"
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => {
                  setStage("idle");
                  setPreview(null);
                }}
                className="flex h-12 items-center gap-2 rounded-2xl border border-white/12 px-5 text-[12px] font-semibold text-[#a39b8d] transition-colors hover:border-white/25 hover:text-[#efe9db]"
              >
                <RotateCcw size={14} />
                Rescan
              </button>
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={confirm}
                disabled={stage === "saved" || !data.amount}
                className="relative flex h-12 flex-1 items-center justify-center gap-2 overflow-hidden rounded-2xl bg-[#ee4413] text-[13px] font-semibold text-[#f4f0e6] shadow-[0_16px_40px_-12px_rgba(238,68,19,0.6)] disabled:opacity-90"
              >
                {stage === "saved" ? (
                  <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2">
                    <Check size={16} strokeWidth={3} /> Inked into the ledger
                  </motion.span>
                ) : (
                  "Log this expense"
                )}
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {stage === "idle" && (
        <p className="mt-5 flex items-center justify-center gap-2 text-center font-mono text-[8.5px] uppercase tracking-[0.22em] text-[#57503f]">
          <FileImage size={11} /> Simulated OCR — everything stays on-device
        </p>
      )}
    </Sheet>
  );
}
