import { useEffect } from "react";
import { motion, useSpring, useTransform } from "framer-motion";
import { formatINR } from "../lib/parser";

interface Props {
  value: number;
  className?: string;
  prefix?: string;
}

/* Spring-drifted number — counts like a balance, not a loader */
export default function AnimatedAmount({ value, className, prefix = "" }: Props) {
  const spring = useSpring(0, { stiffness: 78, damping: 21, mass: 0.9 });

  useEffect(() => {
    spring.set(value);
  }, [value, spring]);

  const text = useTransform(spring, (v) => `${prefix}${formatINR(Math.round(v))}`);

  return <motion.span className={className}>{text}</motion.span>;
}
