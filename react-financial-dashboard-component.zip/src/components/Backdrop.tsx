export default function Backdrop() {
  return (
    <div aria-hidden className="fixed inset-0 -z-10 overflow-hidden bg-[#0d0c09]">
      {/* dot matrix, vignetted */}
      <div className="dot-grid absolute inset-0 opacity-70 [mask-image:radial-gradient(ellipse_75%_65%_at_50%_42%,black_20%,transparent_75%)]" />

      {/* slowly turning conic halo behind the device */}
      <div className="absolute right-[2%] top-1/2 hidden h-[920px] w-[920px] -translate-y-1/2 lg:block">
        <div
          className="animate-rotate-slow h-full w-full rounded-full blur-[36px]"
          style={{
            background:
              "conic-gradient(from 12deg, transparent 0deg, rgba(238,68,19,0.075) 55deg, transparent 120deg, transparent 175deg, rgba(80,110,245,0.07) 245deg, transparent 315deg)",
          }}
        />
      </div>

      {/* color glows */}
      <div className="absolute -top-32 right-[12%] h-[460px] w-[460px] rounded-full bg-[#ee4413]/[0.09] blur-[130px]" />
      <div className="absolute -bottom-24 left-[4%] h-[420px] w-[420px] rounded-full bg-[#506ef5]/[0.08] blur-[130px]" />
      <div className="absolute left-[38%] top-[30%] h-[300px] w-[300px] rounded-full bg-[#efe9db]/[0.025] blur-[100px]" />

      {/* vignette */}
      <div
        className="absolute inset-0"
        style={{ background: "radial-gradient(130% 105% at 50% 0%, transparent 32%, rgba(5,4,3,0.62) 100%)" }}
      />
    </div>
  );
}
