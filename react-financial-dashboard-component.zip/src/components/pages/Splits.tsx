import { useMemo } from "react";
import { motion } from "framer-motion";
import { BellRing, Check, Archive } from "lucide-react";
import AnimatedAmount from "../AnimatedAmount";
import { CATEGORY_META, formatINR } from "../../lib/parser";
import { relLabel, type Friend, type Split } from "../../lib/data";

interface Props {
  splits: Split[];
  friends: Friend[];
  onToggleSettled: (splitId: number, friendId: string) => void;
  onNudge: (name: string) => void;
  onRemove: (splitId: number) => void;
}

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07 } },
};
const rise = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 62, damping: 17 } },
};

export default function Splits({ splits, friends, onToggleSettled, onNudge, onRemove }: Props) {
  const friend = (id: string) => friends.find((f) => f.id === id);

  /* net per friend + totals */
  const perFriend = useMemo(() => {
    const map: Record<string, { owed: number; settled: number }> = {};
    splits.forEach((s) =>
      s.participants.forEach((p) => {
        map[p.friendId] ??= { owed: 0, settled: 0 };
        if (p.settled) map[p.friendId].settled += p.share;
        else map[p.friendId].owed += p.share;
      })
    );
    return map;
  }, [splits]);

  const totalOwed = Object.values(perFriend).reduce((a, c) => a + c.owed, 0);
  const totalSettled = Object.values(perFriend).reduce((a, c) => a + c.settled, 0);

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-5">
      {/* summary banner */}
      <motion.section variants={rise} className="glass relative overflow-hidden rounded-3xl p-6 md:p-8">
        <div
          className="pointer-events-none absolute -left-16 -top-20 h-56 w-56 rounded-full blur-[80px]"
          style={{ background: "rgba(80,110,245,0.12)" }}
        />
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="font-mono text-[9px] uppercase tracking-[0.28em] text-[#57503f]">Friends owe you</p>
            <p className="mt-2 font-display text-[44px] font-semibold leading-none tracking-tight text-[#efe9db] md:text-[52px]">
              ₹<AnimatedAmount value={totalOwed} />
            </p>
          </div>
          <div className="flex gap-6">
            <div>
              <p className="font-mono text-[8.5px] uppercase tracking-[0.22em] text-[#57503f]">Settled so far</p>
              <p className="mt-1.5 font-mono text-[16px] tabular-nums text-[#58cf92]">
                ₹{formatINR(totalSettled)}
              </p>
            </div>
            <div>
              <p className="font-mono text-[8.5px] uppercase tracking-[0.22em] text-[#57503f]">Open splits</p>
              <p className="mt-1.5 font-mono text-[16px] tabular-nums text-[#efe9db]">{splits.length}</p>
            </div>
          </div>
        </div>
      </motion.section>

      {/* friend balances */}
      <motion.section variants={rise} className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {friends.map((f) => {
          const bal = perFriend[f.id] ?? { owed: 0, settled: 0 };
          return (
            <div key={f.id} className="glass rounded-3xl p-4">
              <div className="flex items-center justify-between">
                <span
                  className="grid h-9 w-9 place-items-center rounded-full font-display text-[14px] font-semibold"
                  style={{ background: f.color, color: "#0d0c09" }}
                >
                  {f.name[0]}
                </span>
                {bal.owed > 0 && (
                  <button
                    onClick={() => onNudge(f.name)}
                    aria-label={`Nudge ${f.name}`}
                    title="Send a gentle nudge"
                    className="grid h-7 w-7 place-items-center rounded-full border border-white/10 text-[#7a7266] transition-colors hover:border-[#ee4413]/60 hover:text-[#ee4413]"
                  >
                    <BellRing size={12} />
                  </button>
                )}
              </div>
              <p className="mt-3 text-[13px] font-semibold text-[#efe9db]">{f.name}</p>
              <p
                className="mt-1 font-mono text-[9px] uppercase tracking-[0.14em]"
                style={{ color: bal.owed > 0 ? "#ff7a4d" : "#58cf92" }}
              >
                {bal.owed > 0 ? `owes ₹${formatINR(bal.owed)}` : "all square"}
              </p>
            </div>
          );
        })}
      </motion.section>

      {/* open splits */}
      <div className="space-y-4">
        {splits.map((s) => {
          const meta = CATEGORY_META[s.category] ?? CATEGORY_META.Misc;
          const Icon = meta.icon;
          const settledSum = s.participants.filter((p) => p.settled).reduce((a, c) => a + c.share, 0);
          const friendsShare = s.participants.reduce((a, c) => a + c.share, 0);
          const allSettled = s.participants.every((p) => p.settled);
          return (
            <motion.section key={s.id} variants={rise} className="glass rounded-3xl p-5 md:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3.5">
                  <span
                    className="grid h-11 w-11 shrink-0 place-items-center rounded-xl"
                    style={{ background: `${meta.color}1f`, color: meta.color }}
                  >
                    <Icon size={18} strokeWidth={2} />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[14.5px] font-semibold text-[#efe9db]">{s.title}</p>
                    <p className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.18em] text-[#57503f]">
                      {relLabel(s.date)} · you paid ₹{formatINR(s.total)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[14px] tabular-nums text-[#efe9db]">
                    ₹{formatINR(settledSum)}
                    <span className="text-[#57503f]"> / ₹{formatINR(friendsShare)} back</span>
                  </p>
                  <p className="mt-0.5 font-mono text-[8.5px] uppercase tracking-[0.16em] text-[#57503f]">
                    {allSettled ? "fully settled" : "collecting"}
                  </p>
                </div>
              </div>

              {/* progress */}
              <div className="mt-4 h-[6px] overflow-hidden rounded-full bg-white/[0.06]">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${friendsShare ? (settledSum / friendsShare) * 100 : 0}%` }}
                  transition={{ type: "spring", stiffness: 60, damping: 18 }}
                  className="h-full rounded-full"
                  style={{
                    background: allSettled
                      ? "linear-gradient(90deg,#1c9a67,#58cf92)"
                      : "linear-gradient(90deg,#ee4413,#f5a524)",
                  }}
                />
              </div>

              {/* participants */}
              <div className="mt-4 flex flex-wrap items-center gap-2">
                {s.participants.map((p) => {
                  const f = friend(p.friendId);
                  if (!f) return null;
                  return (
                    <button
                      key={p.friendId}
                      onClick={() => onToggleSettled(s.id, p.friendId)}
                      title={p.settled ? "Mark as pending" : "Mark as settled"}
                      className={`flex items-center gap-2.5 rounded-full border py-1.5 pl-1.5 pr-3.5 transition-all ${
                        p.settled
                          ? "border-[#1c9a67]/50 bg-[#1c9a67]/10"
                          : "border-white/12 bg-white/[0.03] hover:border-white/25"
                      }`}
                    >
                      <span
                        className="grid h-6 w-6 place-items-center rounded-full font-display text-[10px] font-semibold"
                        style={{ background: f.color, color: "#0d0c09" }}
                      >
                        {p.settled ? <Check size={11} strokeWidth={3.2} /> : f.name[0]}
                      </span>
                      <span className={`text-[11.5px] font-semibold ${p.settled ? "text-[#58cf92]" : "text-[#efe9db]"}`}>
                        {f.name}
                      </span>
                      <span className="font-mono text-[10px] tabular-nums text-[#7a7266]">
                        ₹{formatINR(p.share)}
                      </span>
                    </button>
                  );
                })}
                {allSettled && (
                  <button
                    onClick={() => onRemove(s.id)}
                    className="ml-auto flex items-center gap-1.5 rounded-full border border-white/10 px-3.5 py-2 font-mono text-[9px] uppercase tracking-[0.16em] text-[#7a7266] transition-colors hover:border-[#58cf92]/50 hover:text-[#58cf92]"
                  >
                    <Archive size={12} /> Archive
                  </button>
                )}
              </div>
            </motion.section>
          );
        })}

        {splits.length === 0 && (
          <div className="glass grid place-items-center rounded-3xl py-16">
            <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-[#57503f]">
              All square — pick any expense in the ledger to split it
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
