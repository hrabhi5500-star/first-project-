import { motion } from "framer-motion";
import { RefreshCcw } from "lucide-react";
import { CUR_MONTH_NAME, DAYS_IN_MONTH, ELAPSED } from "../../lib/data";
import type { Advisory, Impact } from "../../lib/insights";

const IMPACT_STYLE: Record<Impact, { label: string; fg: string; bg: string; bd: string }> = {
  high: { label: "High impact", fg: "#ff7a4d", bg: "rgba(238,68,19,0.10)", bd: "rgba(238,68,19,0.35)" },
  medium: { label: "Worth it", fg: "#f5a524", bg: "rgba(245,165,36,0.10)", bd: "rgba(245,165,36,0.3)" },
  win: { label: "Keep going", fg: "#58cf92", bg: "rgba(28,154,103,0.12)", bd: "rgba(28,154,103,0.35)" },
};

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};
const rise = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 62, damping: 17 } },
};

export default function Insights({ advisory }: { advisory: Advisory }) {
  const R = 56;
  const CIRC = 2 * Math.PI * R;

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-5">
      {/* ————— verdict header ————— */}
      <motion.section variants={rise} className="glass relative overflow-hidden rounded-3xl p-6 md:p-8">
        <div
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full blur-[90px]"
          style={{ background: "rgba(238,68,19,0.14)" }}
        />
        <div className="flex flex-col items-start gap-8 md:flex-row md:items-center">
          {/* score ring */}
          <div className="relative h-[136px] w-[136px] shrink-0">
            <svg viewBox="0 0 136 136" className="h-full w-full -rotate-90">
              <circle cx="68" cy="68" r={R} fill="none" stroke="rgba(239,233,219,0.07)" strokeWidth="9" />
              <motion.circle
                cx="68"
                cy="68"
                r={R}
                fill="none"
                stroke="url(#scoreGrad)"
                strokeWidth="9"
                strokeLinecap="round"
                strokeDasharray={CIRC}
                initial={{ strokeDashoffset: CIRC }}
                animate={{ strokeDashoffset: CIRC * (1 - advisory.score / 100) }}
                transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
              />
              <defs>
                <linearGradient id="scoreGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#ee4413" />
                  <stop offset="100%" stopColor="#f5a524" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center">
                <motion.p
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7 }}
                  className="font-display text-[34px] font-semibold leading-none text-[#efe9db]"
                >
                  {advisory.score}
                </motion.p>
                <p className="mt-1 font-mono text-[8px] uppercase tracking-[0.24em] text-[#57503f]">
                  money health
                </p>
              </div>
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2.5">
              <span
                className="rounded-full border px-3 py-1 font-mono text-[9px] uppercase tracking-[0.2em]"
                style={{
                  color: advisory.score >= 70 ? "#58cf92" : "#f5a524",
                  borderColor: advisory.score >= 70 ? "rgba(28,154,103,0.4)" : "rgba(245,165,36,0.35)",
                  background: advisory.score >= 70 ? "rgba(28,154,103,0.1)" : "rgba(245,165,36,0.08)",
                }}
              >
                {advisory.grade}
              </span>
              <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#57503f]">
                day {ELAPSED} of {DAYS_IN_MONTH} · {CUR_MONTH_NAME}
              </span>
            </div>
            <h2 className="mt-3 font-display text-[22px] font-medium italic leading-snug text-[#efe9db] md:text-[26px]">
              Your {CUR_MONTH_NAME}, read aloud.
            </h2>
            <p className="mt-3 max-w-2xl text-[13.5px] leading-relaxed text-[#a39b8d]">{advisory.brief}</p>
          </div>
        </div>

        {/* spending DNA */}
        <div className="mt-7 grid grid-cols-2 gap-3 md:grid-cols-4">
          {advisory.facts.map((f, i) => (
            <motion.div
              key={f.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.08 }}
              className="rounded-2xl border border-white/[0.07] bg-white/[0.025] px-4 py-3.5"
            >
              <p className="font-mono text-[8px] uppercase tracking-[0.22em] text-[#57503f]">{f.label}</p>
              <p className="mt-1.5 truncate text-[15px] font-semibold text-[#efe9db]">{f.value}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* ————— tips ————— */}
      <div className="grid gap-4 md:grid-cols-2">
        {advisory.tips.map((tip) => {
          const st = IMPACT_STYLE[tip.impact];
          const Ico = tip.icon;
          return (
            <motion.article key={tip.id} variants={rise} className="glass group rounded-3xl p-5 md:p-6">
              <div className="flex items-start justify-between gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl border border-white/[0.08] bg-white/[0.03]">
                  <Ico size={17} strokeWidth={2} className="text-[#ee4413]" />
                </span>
                <span
                  className="rounded-full border px-2.5 py-1 font-mono text-[8px] uppercase tracking-[0.18em]"
                  style={{ color: st.fg, background: st.bg, borderColor: st.bd }}
                >
                  {st.label}
                </span>
              </div>
              <p className="mt-4 font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">{tip.tag}</p>
              <h3 className="mt-1.5 text-[15px] font-semibold leading-snug text-[#efe9db]">{tip.title}</h3>
              <p className="mt-2.5 text-[12.5px] leading-relaxed text-[#8d8577]">{tip.body}</p>
            </motion.article>
          );
        })}
      </div>

      {/* method note */}
      <motion.p
        variants={rise}
        className="flex items-center justify-center gap-2 py-2 text-center font-mono text-[8.5px] uppercase tracking-[0.22em] text-[#3d382f]"
      >
        <RefreshCcw size={10} />
        Re-computed live from your ledger as you type, scan and split — never uploaded
      </motion.p>
    </motion.div>
  );
}
