import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, Trash2, Users } from "lucide-react";
import { CATEGORY_META, formatINR } from "../../lib/parser";
import { relLabel, type Tx } from "../../lib/data";

interface Props {
  txs: Tx[];
  onSplit: (tx: Tx) => void;
  onDelete: (id: number) => void;
}

type Filter = "all" | "expense" | "income";

export default function Transactions({ txs, onSplit, onDelete }: Props) {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return txs.filter((t) => {
      if (filter !== "all" && t.type !== filter) return false;
      if (!needle) return true;
      return (
        t.merchant.toLowerCase().includes(needle) ||
        (t.note ?? "").toLowerCase().includes(needle) ||
        t.category.toLowerCase().includes(needle) ||
        String(t.amount).includes(needle)
      );
    });
  }, [txs, q, filter]);

  /* group by date, newest first */
  const groups = useMemo(() => {
    const map = new Map<string, Tx[]>();
    filtered.forEach((t) => {
      const arr = map.get(t.date) ?? [];
      arr.push(t);
      map.set(t.date, arr);
    });
    return [...map.entries()].sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  return (
    <div className="space-y-5">
      {/* controls */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center"
      >
        <div className="glass flex flex-1 items-center gap-3 rounded-full px-4">
          <Search size={15} className="shrink-0 text-[#57503f]" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search merchant, note, amount…"
            className="min-w-0 flex-1 bg-transparent py-3 text-[13px] text-[#efe9db] outline-none placeholder:text-[#57503f]"
          />
        </div>
        <div className="flex gap-1.5">
          {(
            [
              ["all", "All"],
              ["expense", "Out"],
              ["income", "In"],
            ] as [Filter, string][]
          ).map(([f, label]) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full border px-4 py-2.5 font-mono text-[9.5px] uppercase tracking-[0.16em] transition-colors ${
                filter === f
                  ? "border-[#ee4413]/60 bg-[#ee4413]/[0.1] text-[#efe9db]"
                  : "border-white/10 text-[#7a7266] hover:border-white/25"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </motion.div>

      <p className="font-mono text-[9px] uppercase tracking-[0.24em] text-[#57503f]">
        {filtered.length} {filtered.length === 1 ? "entry" : "entries"}
      </p>

      {/* grouped list */}
      <div className="space-y-6">
        {groups.map(([date, rows], gi) => (
          <motion.section
            key={date}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(gi * 0.05, 0.4), type: "spring", stiffness: 70, damping: 18 }}
          >
            <div className="mb-2 flex items-center gap-3">
              <span className="font-mono text-[9px] uppercase tracking-[0.24em] text-[#7a7266]">
                {relLabel(date)}
              </span>
              <span className="h-px flex-1 bg-white/[0.06]" />
              <span className="font-mono text-[9px] tabular-nums text-[#57503f]">
                −₹{formatINR(rows.filter((r) => r.type === "expense").reduce((a, c) => a + c.amount, 0))}
              </span>
            </div>

            <div className="glass divide-y divide-white/[0.05] overflow-hidden rounded-3xl">
              <AnimatePresence initial={false}>
                {rows.map((t) => {
                  const meta = CATEGORY_META[t.category] ?? CATEGORY_META.Misc;
                  const Icon = meta.icon;
                  return (
                    <motion.div
                      key={t.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0, x: -32, height: 0, paddingTop: 0, paddingBottom: 0 }}
                      transition={{ type: "spring", stiffness: 380, damping: 34 }}
                      className="group flex items-center gap-3.5 px-4 py-3.5 md:px-5"
                    >
                      <span
                        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl"
                        style={{ background: `${meta.color}1f`, color: meta.color }}
                      >
                        <Icon size={16} strokeWidth={2.1} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13.5px] font-semibold text-[#efe9db]">{t.merchant}</p>
                        <p className="mt-0.5 truncate font-mono text-[8.5px] uppercase tracking-[0.14em] text-[#57503f]">
                          {t.category}
                          {t.note ? ` · ${t.note}` : ""}
                          {t.source === "scan" ? " · scanned" : ""}
                        </p>
                      </div>

                      <div className="flex shrink-0 items-center gap-2">
                        <p
                          className="font-mono text-[13.5px] tabular-nums"
                          style={{ color: t.type === "income" ? "#58cf92" : "#efe9db" }}
                        >
                          {t.type === "income" ? "+" : "−"}₹{formatINR(t.amount)}
                        </p>
                        {/* actions — reveal on hover (desktop), always on touch */}
                        <div className="flex items-center gap-1 opacity-100 transition-opacity md:opacity-0 md:group-hover:opacity-100">
                          {t.type === "expense" && (
                            <button
                              onClick={() => onSplit(t)}
                              aria-label={`Split ${t.merchant}`}
                              title="Split this bill"
                              className="grid h-8 w-8 place-items-center rounded-full border border-white/10 text-[#7a7266] transition-colors hover:border-[#ee4413]/60 hover:text-[#ee4413]"
                            >
                              <Users size={13} />
                            </button>
                          )}
                          <button
                            onClick={() => onDelete(t.id)}
                            aria-label={`Delete ${t.merchant}`}
                            title="Strike out"
                            className="grid h-8 w-8 place-items-center rounded-full border border-white/10 text-[#7a7266] transition-colors hover:border-[#ff7a4d]/60 hover:text-[#ff7a4d]"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </motion.section>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="glass grid place-items-center rounded-3xl py-16">
          <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-[#57503f]">
            Nothing matches — the ledger shrugs
          </p>
        </div>
      )}
    </div>
  );
}
