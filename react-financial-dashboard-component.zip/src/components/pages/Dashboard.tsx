import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Send, ArrowRight, TrendingDown, TrendingUp } from "lucide-react";
import AnimatedAmount from "../AnimatedAmount";
import { CategoryDonut, TrendChart } from "../charts/Charts";
import { CATEGORY_META, formatINR, guessMerchant, parseNote } from "../../lib/parser";
import {
  BUDGETS,
  CUR_KEY,
  CUR_MONTH_NAME,
  PACE,
  PREV_KEY,
  PREV_MONTH_NAME,
  TODAY_ISO,
  byCategory,
  cumulativeSeries,
  monthExpense,
  monthIncome,
  relLabel,
  type Tx,
} from "../../lib/data";
import type { NewTx } from "../../lib/useLedger";
import type { Advisory } from "../../lib/insights";
import type { PageId } from "../layout/Chrome";

interface Props {
  txs: Tx[];
  advisory: Advisory;
  onQuickAdd: (t: NewTx) => void;
  onNav: (p: PageId) => void;
}

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.05 } },
};
const rise = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 60, damping: 17 } },
};

export default function Dashboard({ txs, advisory, onQuickAdd, onNav }: Props) {
  const [note, setNote] = useState("");

  const curSpent = useMemo(() => monthExpense(txs, CUR_KEY), [txs]);
  const curIn = useMemo(() => monthIncome(txs, CUR_KEY), [txs]);
  const prevSpent = useMemo(() => monthExpense(txs, PREV_KEY), [txs]);
  const balance = useMemo(
    () => txs.filter((t) => t.type === "income").reduce((a, c) => a + c.amount, 0) - txs.filter((t) => t.type === "expense").reduce((a, c) => a + c.amount, 0),
    [txs]
  );
  const trend = useMemo(() => cumulativeSeries(txs), [txs]);
  const byCat = useMemo(() => byCategory(txs, CUR_KEY), [txs]);
  const recent = txs.slice(0, 6);
  const parsed = note.trim() ? parseNote(note) : null;

  const spendDelta = prevSpent ? (curSpent - prevSpent) / prevSpent : 0;
  const paceDelta = advisory.paceRatio - 1;

  const submitQuick = (e: React.FormEvent) => {
    e.preventDefault();
    if (!note.trim() || !parsed) return;
    onQuickAdd({
      type: parsed.type,
      amount: parsed.amount,
      category: parsed.category,
      merchant: guessMerchant(note),
      note: note.trim(),
      date: TODAY_ISO,
      source: "note",
    });
    setNote("");
  };

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-5">
      {/* ————— natural-language quick log ————— */}
      <motion.form
        variants={rise}
        onSubmit={submitQuick}
        className="glass relative flex items-center gap-3 rounded-2xl px-4 py-1.5 md:rounded-full md:px-5"
      >
        <Sparkles size={15} className="shrink-0 text-[#ee4413]" />
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder='Try "spent ₹500 on dinner" or "received 2k freelance"'
          className="min-w-0 flex-1 bg-transparent py-3.5 text-[13.5px] text-[#efe9db] outline-none placeholder:text-[#57503f]"
        />
        {parsed && (
          <span className="hidden shrink-0 items-center gap-2 rounded-full border border-white/10 px-3 py-1 font-mono text-[9px] uppercase tracking-[0.12em] text-[#a39b8d] sm:flex">
            {parsed.category} ·
            <span style={{ color: parsed.type === "income" ? "#58cf92" : "#ff7a4d" }}>
              {parsed.type === "income" ? "+" : "−"}₹{parsed.hasAmount ? formatINR(parsed.amount) : "···"}
            </span>
          </span>
        )}
        <motion.button
          whileTap={{ scale: 0.88 }}
          type="submit"
          disabled={!note.trim()}
          aria-label="Quick log"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#ee4413] text-[#f4f0e6] transition-opacity disabled:opacity-30"
        >
          <Send size={14} className="ml-0.5" />
        </motion.button>
      </motion.form>

      {/* ————— stat cards ————— */}
      <motion.div variants={stagger} className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          label="Total balance"
          value={balance}
          foot="across all entries"
          prefix="₹"
        />
        <StatCard
          label={`Out in ${CUR_MONTH_NAME}`}
          value={curSpent}
          prefix="₹"
          foot={
            <>
              {paceDelta > 0 ? (
                <TrendingUp size={11} className="text-[#ff7a4d]" />
              ) : (
                <TrendingDown size={11} className="text-[#58cf92]" />
              )}
              <span className={paceDelta > 0 ? "text-[#ff7a4d]" : "text-[#58cf92]"}>
                {Math.abs(Math.round(paceDelta * 100))}% {paceDelta > 0 ? "ahead of" : "under"} {PREV_MONTH_NAME} pace
              </span>
            </>
          }
        />
        <StatCard label={`In during ${CUR_MONTH_NAME}`} value={curIn} prefix="₹" foot="salary + freelance" tone="in" />
        <div className="glass rounded-3xl p-5">
          <p className="font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">Savings rate</p>
          <p className="mt-2.5 font-display text-[30px] font-semibold leading-none text-[#efe9db]">
            <AnimatedAmount value={Math.round(advisory.savingsRate * 100)} className="tabular-nums" />
            <span className="text-[18px] text-[#7a7266]">%</span>
          </p>
          <p className="mt-2 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-[#7a7266]">
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ background: advisory.grade === "Excellent" || advisory.grade === "Solid" ? "#1c9a67" : "#ee4413" }}
            />
            {advisory.grade} — {advisory.score}/100
          </p>
        </div>
      </motion.div>

      {/* ————— trend + donut ————— */}
      <div className="grid gap-5 lg:grid-cols-3">
        <motion.section variants={rise} className="glass rounded-3xl p-5 md:p-6 lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-[19px] font-medium italic text-[#efe9db]">Spending pulse</h2>
              <p className="mt-1 font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">
                Cumulative, day by day
              </p>
            </div>
            <div className="flex items-center gap-3 font-mono text-[9px] uppercase tracking-[0.14em] text-[#7a7266]">
              <span className="flex items-center gap-1.5">
                <span className="h-[3px] w-4 rounded-full bg-[#ee4413]" /> {CUR_MONTH_NAME}
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-[3px] w-4 rounded-full border-t-2 border-dashed border-[#57503f]" /> {PREV_MONTH_NAME}
              </span>
              <span className="hidden text-[#57503f] sm:inline">
                {spendDelta > 0 ? "+" : ""}
                {Math.round(spendDelta * 100)}% total
              </span>
            </div>
          </div>
          <div className="mt-4">
            <TrendChart data={trend} curName={CUR_MONTH_NAME} prevName={PREV_MONTH_NAME} />
          </div>
        </motion.section>

        <motion.section variants={rise} className="glass rounded-3xl p-5 md:p-6">
          <h2 className="font-display text-[19px] font-medium italic text-[#efe9db]">Where it went</h2>
          <p className="mt-1 font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">By category</p>
          <div className="mt-2">
            <CategoryDonut data={byCat} total={curSpent} />
          </div>
          <div className="mt-2 space-y-2">
            {byCat.slice(0, 4).map((c) => (
              <div key={c.name} className="flex items-center gap-2.5">
                <span
                  className="h-2 w-2 rounded-[3px]"
                  style={{ background: CATEGORY_META[c.name]?.color ?? "#6b6457" }}
                />
                <span className="flex-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-[#a39b8d]">
                  {c.name}
                </span>
                <span className="font-mono text-[11px] tabular-nums text-[#efe9db]">₹{formatINR(c.value)}</span>
              </div>
            ))}
          </div>
        </motion.section>
      </div>

      {/* ————— budgets + advisor teaser ————— */}
      <div className="grid gap-5 lg:grid-cols-3">
        <motion.section variants={rise} className="glass rounded-3xl p-5 md:p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-[19px] font-medium italic text-[#efe9db]">Budget pace</h2>
              <p className="mt-1 font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">
                {Math.round(PACE * 100)}% of {CUR_MONTH_NAME} has elapsed — white ticks mark expected pace
              </p>
            </div>
          </div>
          <div className="mt-5 space-y-4">
            {BUDGETS.map((b, i) => {
              const spent = byCat.find((c) => c.name === b.category)?.value ?? 0;
              const pct = Math.min(1, spent / b.limit);
              const over = spent / b.limit > PACE;
              return (
                <div key={b.category}>
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-[#a39b8d]">
                      {b.category}
                    </span>
                    <span className="font-mono text-[10px] tabular-nums text-[#7a7266]">
                      ₹{formatINR(spent)} <span className="text-[#57503f]">/ ₹{formatINR(b.limit)}</span>
                    </span>
                  </div>
                  <div className="relative h-[7px] overflow-hidden rounded-full bg-white/[0.06]">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct * 100}%` }}
                      transition={{ duration: 0.9, delay: 0.15 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                      className="h-full rounded-full"
                      style={{
                        background: over
                          ? "linear-gradient(90deg, #ee4413, #f5a524)"
                          : "linear-gradient(90deg, #1c9a67, #58cf92)",
                      }}
                    />
                    {/* pace tick */}
                    <span
                      className="absolute -top-[1px] h-[9px] w-[2px] bg-[#efe9db]/70"
                      style={{ left: `calc(${PACE * 100}% - 1px)` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </motion.section>

        {/* advisor teaser */}
        <motion.section
          variants={rise}
          className="glass relative overflow-hidden rounded-3xl p-5 md:p-6"
        >
          <div
            className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full blur-[70px]"
            style={{ background: "rgba(238,68,19,0.14)" }}
          />
          <div className="flex items-center gap-2">
            <Sparkles size={14} className="text-[#ee4413]" />
            <h2 className="font-display text-[19px] font-medium italic text-[#efe9db]">Advisor's note</h2>
          </div>
          <p className="mt-4 text-[13px] leading-relaxed text-[#a39b8d]">
            {advisory.brief.length > 170 ? advisory.brief.slice(0, 170).trimEnd() + "…" : advisory.brief}
          </p>
          {advisory.tips[0] && (
            <div className="mt-4 rounded-2xl border border-white/[0.08] bg-white/[0.03] p-4">
              <p className="font-mono text-[8px] uppercase tracking-[0.22em] text-[#ee4413]">
                {advisory.tips[0].tag}
              </p>
              <p className="mt-1.5 text-[12.5px] font-semibold leading-snug text-[#efe9db]">
                {advisory.tips[0].title}
              </p>
            </div>
          )}
          <button
            onClick={() => onNav("insights")}
            className="group mt-5 inline-flex items-center gap-2 font-mono text-[9.5px] uppercase tracking-[0.22em] text-[#7a7266] transition-colors hover:text-[#efe9db]"
          >
            Read the full advisory
            <ArrowRight size={13} className="transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </motion.section>
      </div>

      {/* ————— recent activity ————— */}
      <motion.section variants={rise} className="glass rounded-3xl p-5 md:p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-[19px] font-medium italic text-[#efe9db]">Fresh ink</h2>
          <button
            onClick={() => onNav("transactions")}
            className="group flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.2em] text-[#7a7266] transition-colors hover:text-[#efe9db]"
          >
            Full ledger
            <ArrowRight size={12} className="transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </div>
        <div className="mt-3 divide-y divide-white/[0.05]">
          {recent.map((t) => {
            const meta = CATEGORY_META[t.category] ?? CATEGORY_META.Misc;
            const Icon = meta.icon;
            return (
              <div key={t.id} className="flex items-center gap-3.5 py-3">
                <span
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl"
                  style={{ background: `${meta.color}1f`, color: meta.color }}
                >
                  <Icon size={15} strokeWidth={2.1} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-semibold text-[#efe9db]">{t.merchant}</p>
                  <p className="mt-0.5 truncate font-mono text-[8.5px] uppercase tracking-[0.14em] text-[#57503f]">
                    {t.category} · {relLabel(t.date)}
                    {t.source === "scan" ? " · scanned" : t.source === "note" ? " · typed" : ""}
                  </p>
                </div>
                <p
                  className="shrink-0 font-mono text-[13px] tabular-nums"
                  style={{ color: t.type === "income" ? "#58cf92" : "#efe9db" }}
                >
                  {t.type === "income" ? "+" : "−"}₹{formatINR(t.amount)}
                </p>
              </div>
            );
          })}
        </div>
      </motion.section>
    </motion.div>
  );
}

function StatCard({
  label,
  value,
  prefix = "",
  foot,
  tone,
}: {
  label: string;
  value: number;
  prefix?: string;
  foot?: React.ReactNode;
  tone?: "in";
}) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 22 },
        show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 60, damping: 17 } },
      }}
      className="glass rounded-3xl p-5"
    >
      <p className="font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">{label}</p>
      <p
        className="mt-2.5 font-display text-[28px] font-semibold leading-none tracking-tight md:text-[30px]"
        style={{ color: tone === "in" ? "#58cf92" : "#efe9db" }}
      >
        {prefix}
        <AnimatedAmount value={value} className="tabular-nums" />
      </p>
      {foot && (
        <p className="mt-2 flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.12em] text-[#7a7266]">
          {foot}
        </p>
      )}
    </motion.div>
  );
}
