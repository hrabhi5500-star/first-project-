import { motion } from "framer-motion";
import {
  LayoutGrid,
  Receipt,
  Users,
  Sparkles,
  Plus,
  ScanLine,
  type LucideIcon,
} from "lucide-react";
import { CUR_MONTH_NAME, CUR_YEAR } from "../../lib/data";

export type PageId = "dashboard" | "transactions" | "splits" | "insights";

export const NAV: { id: PageId; label: string; icon: LucideIcon }[] = [
  { id: "dashboard", label: "Overview", icon: LayoutGrid },
  { id: "transactions", label: "Ledger", icon: Receipt },
  { id: "splits", label: "Splits", icon: Users },
  { id: "insights", label: "Advisor", icon: Sparkles },
];

export const PAGE_TITLES: Record<PageId, { title: string; sub: string }> = {
  dashboard: { title: "Overview", sub: `${CUR_MONTH_NAME} ${CUR_YEAR} · live ledger` },
  transactions: { title: "Every entry", sub: "Search, split, strike out" },
  splits: { title: "Between friends", sub: "Who owes what — settled gently" },
  insights: { title: "The advisor", sub: "On-device reading of your habits" },
};

/* ————— desktop sidebar ————— */
export function Sidebar({ page, onNav }: { page: PageId; onNav: (p: PageId) => void }) {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-white/[0.06] bg-[#0b0a08]/80 backdrop-blur-xl md:flex">
      <div className="px-6 pb-8 pt-7">
        <span className="font-display text-[26px] font-semibold italic leading-none text-[#efe9db]">
          Folio<span className="align-super font-mono text-[9px] not-italic text-[#ee4413]">®</span>
        </span>
        <p className="mt-2 font-mono text-[8.5px] uppercase tracking-[0.3em] text-[#57503f]">
          Quiet money · {CUR_YEAR}
        </p>
      </div>

      <nav className="flex-1 space-y-1.5 px-3.5">
        {NAV.map((item) => {
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNav(item.id)}
              className={`group relative flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-left transition-colors ${
                active ? "text-[#efe9db]" : "text-[#7a7266] hover:text-[#a39b8d]"
              }`}
            >
              {active && (
                <motion.span
                  layoutId="nav-pill"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  className="absolute inset-0 rounded-xl border border-white/[0.08] bg-white/[0.045]"
                />
              )}
              <item.icon size={16} strokeWidth={2.2} className={`relative z-10 ${active ? "text-[#ee4413]" : ""}`} />
              <span className="relative z-10 font-mono text-[10.5px] uppercase tracking-[0.2em]">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4">
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-[8.5px] uppercase tracking-[0.24em] text-[#57503f]">Paper meter</p>
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: "38%" }}
              transition={{ duration: 1.2, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="h-full rounded-full bg-gradient-to-r from-[#ee4413] to-[#f5a524]"
            />
          </div>
          <p className="mt-2.5 text-[11px] leading-relaxed text-[#7a7266]">
            Local-first. Your ledger never leaves this browser tab.
          </p>
        </div>
      </div>
    </aside>
  );
}

/* ————— top bar ————— */
export function TopBar({
  page,
  onAdd,
  onScan,
}: {
  page: PageId;
  onAdd: () => void;
  onScan: () => void;
}) {
  const meta = PAGE_TITLES[page];
  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-[#0d0c09]/75 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-3 px-4 py-4 md:px-8">
        <div className="flex items-center gap-3 md:block">
          <span className="font-display text-[22px] font-semibold italic text-[#efe9db] md:hidden">
            Folio<span className="align-super font-mono text-[8px] not-italic text-[#ee4413]">®</span>
          </span>
          <div className="hidden md:block">
            <motion.h1
              key={page}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-display text-[26px] font-medium italic leading-none text-[#efe9db]"
            >
              {meta.title}
            </motion.h1>
            <p className="mt-1.5 font-mono text-[9px] uppercase tracking-[0.26em] text-[#57503f]">{meta.sub}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="hidden rounded-full border border-white/10 px-3.5 py-2 font-mono text-[9px] uppercase tracking-[0.2em] text-[#7a7266] sm:block">
            {CUR_MONTH_NAME} '{String(CUR_YEAR).slice(2)}
          </span>
          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={onScan}
            className="flex h-10 items-center gap-2 rounded-full border border-white/12 px-3.5 text-[12px] font-semibold text-[#efe9db] transition-colors hover:border-[#ee4413]/60 hover:text-[#ee4413] md:px-4"
          >
            <ScanLine size={15} strokeWidth={2.2} />
            <span className="hidden sm:inline">Scan receipt</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.94 }}
            onClick={onAdd}
            className="flex h-10 items-center gap-2 rounded-full bg-[#ee4413] px-4 text-[12px] font-semibold text-[#f4f0e6] shadow-[0_12px_30px_-10px_rgba(238,68,19,0.55)] transition-colors hover:bg-[#ff541f]"
          >
            <Plus size={15} strokeWidth={2.6} />
            <span className="hidden sm:inline">Quick add</span>
          </motion.button>
        </div>
      </div>
    </header>
  );
}

/* ————— mobile dock ————— */
export function MobileDock({
  page,
  onNav,
  onAdd,
}: {
  page: PageId;
  onNav: (p: PageId) => void;
  onAdd: () => void;
}) {
  return (
    <nav className="fixed inset-x-3 bottom-3 z-40 md:hidden">
      <div className="flex items-end justify-between rounded-[22px] border border-white/[0.09] bg-[#14120e]/92 px-2 pb-2 pt-2 shadow-[0_24px_60px_-16px_rgba(0,0,0,0.8)] backdrop-blur-xl">
        {NAV.slice(0, 2).map((item) => (
          <DockButton key={item.id} item={item} active={page === item.id} onClick={() => onNav(item.id)} />
        ))}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onAdd}
          aria-label="Quick add"
          className="-mt-7 grid h-13 w-13 shrink-0 place-items-center rounded-full bg-[#ee4413] text-[#f4f0e6] shadow-[0_14px_34px_-8px_rgba(238,68,19,0.65)]"
          style={{ height: 52, width: 52 }}
        >
          <Plus size={22} strokeWidth={2.6} />
        </motion.button>
        {NAV.slice(2).map((item) => (
          <DockButton key={item.id} item={item} active={page === item.id} onClick={() => onNav(item.id)} />
        ))}
      </div>
    </nav>
  );
}

function DockButton({
  item,
  active,
  onClick,
}: {
  item: { label: string; icon: LucideIcon };
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-1 flex-col items-center gap-1 rounded-xl py-2 transition-colors ${
        active ? "text-[#efe9db]" : "text-[#57503f]"
      }`}
    >
      <item.icon size={19} strokeWidth={2.1} className={active ? "text-[#ee4413]" : ""} />
      <span className="font-mono text-[8px] uppercase tracking-[0.14em]">{item.label}</span>
    </button>
  );
}
